<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="css/login3.css">
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="assets/wnet-image.png" alt="wildnet-img">
        </div>
        <div class="login-box">
            <form id="sendotpform" action="" method="POST" novalidate>
                <h3 class="head">Forgot Passord</h3>
                <div class="form-group">
                    <label for="email" class="form-label">Enter Email Address</label>
                    <input type="email" name="email" id="email" placeholder="Enter email to get password OTP" required>
                    <small class="error" style="color:red;display:none;">Please enter a valid email.</small>
                    <a id="edit-link" style="display: none;" href="#">Edit Email Id</a>
                </div>
                <!-- <div class="form-group otp-notice" style="display:none;">
                    <h4>OTP Sent to Email Id</h4>
                    <a class="edit-link" href="#">Edit Email Id</a>
                </div> -->
                <div class="form-group otp-field" style="display:none;">
                    <label for="otp" class="form-label">Enter OTP</label>
                    <input type="text" name="otp" id="otp" placeholder="Enter OTP To Reset Passord" required>
                    <small class="error" style="color:red;display:none;">Please enter a valid otp.</small>
                </div>
                <button type="submit" class="login-btn">Request OTP</button>
                <a href="index.php" class="forgot-password">Back</a>

            </form>
        </div>
    </div>
    <footer></footer>

    <!-- <script>
        document.getElementById('sendotpform').addEventListener('submit', function (e) {
            let valid = true;

            // Email validation
            const email = document.getElementById('email');
            const emailError = email.nextElementSibling;
            const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            if (!email.value.match(emailPattern)) {
                emailError.style.display = 'block';
                valid = false;
            } else {
                emailError.style.display = 'none';
            }

            // Password validation
            // const otp = document.getElementById('otp');
            // const otpError = otp.nextElementSibling;
            // if (password.value.length < 6) {
            //     passwordError.style.display = 'block';
            //     valid = false;
            // } else {
            //     passwordError.style.display = 'none';
            // }

            if (!valid) {
                e.preventDefault(); // Stop form submission if validation fails
            }
        });
    </script> -->


    <script>
        document.getElementById('sendotpform').addEventListener('submit', function (e) {
            e.preventDefault();

            const emailInput = document.getElementById('email');
            const emailError = emailInput.nextElementSibling;
            const otpInput = document.getElementById('otp');
            const otpError = otpInput.nextElementSibling;
            const otpField = document.querySelector('.otp-field');
            const editLink = document.getElementById('edit-link');
            const button = document.querySelector('.login-btn');

            const email = emailInput.value.trim();
            const otp = otpInput.value.trim();

            // Validate email
            const emailPattern = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
            let isValid = true;

            if (!emailPattern.test(email)) {
                emailError.style.display = 'block';
                isValid = false;
            } else {
                emailError.style.display = 'none';
            }

            // If OTP is visible, validate OTP too
            if (otpField.style.display !== 'none') {
                if (!/^\d{6}$/.test(otp)) {
                    otpError.style.display = 'block';
                    isValid = false;
                } else {
                    otpError.style.display = 'none';
                }
            }

            editLink.addEventListener('click', function () {
                emailInput.disabled = false;
                otpField.style.display = 'none';
                button.textContent = 'Request OTP';
                this.style.display = 'none';
            });


            if (!isValid) return;

            // Proceed based on phase
            if (otpField.style.display === 'none') {
                // STEP 1: Request OTP
                button.disabled = true;
                button.textContent = 'Please Wait';

                fetch('api/otp-handler.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        action: 'send',
                        email: email
                    })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert('OTP sent to your email.');
                            otpField.style.display = 'block';
                            emailInput.disabled = true;
                            editLink.style.display = 'inline-block';
                            button.textContent = 'Verify OTP';
                        } else {
                            alert(data.message || 'Failed to send OTP.');
                            if(data.message == 'Email not registered.') emailError.textContent = 'Email not registered.';
                            emailError.style.display = 'block';
                            button.textContent = 'Request OTP';
                        }
                        button.disabled = false;
                    });
            } else {
                // STEP 2: Verify OTP
                button.disabled = true;
                button.textContent = 'Please Wait';

                fetch('api/otp-handler.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        action: 'verify',
                        email: email,
                        otp: otp
                    })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert('OTP verified. Redirecting to password reset...');
                            window.location.href = `reset-password.php?email=${encodeURIComponent(email)}`;
                        } else {
                            alert(data.message || 'Invalid OTP.');
                            button.textContent = 'Verify OTP';
                        }
                        button.disabled = false;
                    });
            }
        });
    </script>


</body>

</html>