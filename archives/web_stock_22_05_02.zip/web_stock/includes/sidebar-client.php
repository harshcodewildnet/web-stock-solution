<aside>
    <nav class="sidenav">
        <div class="nav-tabs">
            <!-- <?php
            $dashboardLink = ($_SESSION['user_role'] === 'admin') ? 'dashboard.php' : 'dashboard-client.php';
            ?>
            <a href="<?php echo $dashboardLink; ?>">
                <button type="button" class="tab active"><i class="fa-solid fa-house"></i>Dashboard</button>
            </a> -->
            <a href="dashboard-client.php" class="tab">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
            <a href="dblist.php" class="tab">
                <i class="fa-solid fa-bars-staggered"></i> DB List
            </a>
            <a href="add-website.php" class="tab">
                <i class="fa-solid fa-square-plus"></i> Add Website
            </a>
            <a href="manage-profile.php" class="tab">
                <i class="fa-solid fa-user"></i> Profile
            </a>
        </div>
        <a href="#" class="logout-btn" id="logout-btn">
            <i class="fa-solid fa-power-off"></i> Log out
        </a>
    </nav>
</aside>