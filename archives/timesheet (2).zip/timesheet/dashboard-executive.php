<?php
require_once 'config/config.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="assets/js/add.js"></script>
</head>

<body>
    <!-- Header Dblist-->
    <header>
        <a href="dashboard.php">
            <div class="logo">
                <img src="assets/images/wnet-image.png" alt="WildNet logo">
            </div>
        </a>
        <div class="search-area">
            <h3 class="head">Welcome User</h3>
            <div class="actions">
                <label id="profile-label">
                    <i class="fa-solid fa-user"></i>
                    <button id="profile-toggle">
                        <i class="fa-solid fa-caret-down"></i>
                    </button>
                    <div id="profile-dropdown" class="profile-dropdown">
                        <a href="manage-profile.php" class="dropdown-item">My Profile</a>
                        <hr>
                        <a href="manage-profile.php" class="dropdown-item">Reset Password</a>
                    </div>
                </label>
                <a href="#" id="logout-link">
                    <i class="fa-solid fa-power-off"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </header>
    <aside>
        <nav class="sidenav">
            <div class="nav-tabs">
                <a href="index.php" class="tab">
                    <i class="fa-solid fa-house"></i> Home
                </a>
                <!-- <a href="manage-user.php" class="tab">
                    <i class="fa-solid fa-user"></i> Manage User
                </a> -->
                <a href="profile.php" class="tab">
                    <i class="fa-solid fa-user"></i> My Account
                </a>
            </div>
        </nav>
    </aside>
    <main>
        <!-- top panel -->
        <div class="top-panel">
            <!-- Filter Boxes -->
            <div class="filler"></div>
            <!-- <div class="filters">
                <div class="filter-multiselect">
                    <div class="select-box">Department<i class="fa-solid fa-caret-down"></i></div>
                    <div class="options">
                        <label><input type="checkbox" class="select-all" value="">Select All</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="General">General</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="Technology">Technology</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="Travel">Travel</label>
                    </div>
                </div>
                <div class="filter-multiselect">
                    <div class="select-box">Employee Name<i class="fa-solid fa-caret-down"></i></div>
                    <div class="options">
                        <label><input type="checkbox" class="select-all" value="">Select All</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="General">General</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="Technology">Technology</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="Travel">Travel</label>
                    </div>
                </div>
                <div class="filter-multiselect">
                    <div class="select-box">Select Month<i class="fa-solid fa-caret-down"></i></div>
                    <div class="options">
                        <label><input type="checkbox" class="select-all" value="">Select All</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="General">General</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="Technology">Technology</label>
                        <label><input type="checkbox" class="filter-option category-filter"
                                value="Travel">Travel</label>
                    </div>
                </div>
            </div> -->
            <div class="details-card">
                <h4 class="card-title">Quick Analysis</h4>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-leaf"></i></span>
                    <span class="label">Total leaves -</span>
                    <span class="value">0</span>
                </div>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-calendar-days"></i></span>
                    <span class="label green">Total days -</span>
                    <span class="value">22</span>
                </div>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-square-plus"></i></span>
                    <span class="label blue">Gross Hours -</span>
                    <span class="value">176h22m</span>
                </div>
            </div>
        </div>
        <!-- content -->
        <div class="content-area">
            <div class="table-wrapper">
                <table class="sitelist">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Working/Leave</th>
                            <th>Nature of Task</th>
                            <th>Task Brief</th>
                            <th>Time Taken</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="siteTableBody">
                        <tr class="entry-row">
                            <td><input type="date"></td>
                            <td>
                                <select name="">
                                    <option value="">Working</option>
                                    <option value="">Leave</option>
                                </select>
                            </td>
                            <td><input type="text" placeholder="Enter Task Category"></td>
                            <td><input type="text" placeholder="Enter Task Description"></td>
                            <td>
                                <select name="time" id="time">
                                    <option value="">0:30</option>
                                    <option value="">1:00</option>
                                    <option value="">1:30</option>
                                    <option value="">2:00</option>
                                    <option value="">2:30</option>
                                </select>
                            </td>
                            <td>
                                -
                            </td>
                        </tr>
                        <!-- <tr class="add-btn-row">
                            <td colspan="7">
                                <button class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
                            </td>
                        </tr> -->
                    </tbody>
                </table>
                <button class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
            </div>

        </div>
    </main>
    <!-- <footer></footer> -->
    <script src="assets/js/filters.js"></script>
</body>

</html>