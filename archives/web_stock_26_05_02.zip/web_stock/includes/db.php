<?php
$host = 'webstock.site4demo.com';
$user = 'webstocksite4dem_webstocku';
$password = 'dVZ^.Je^!@]X';
$db = 'webstocksite4dem_webstock';

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
