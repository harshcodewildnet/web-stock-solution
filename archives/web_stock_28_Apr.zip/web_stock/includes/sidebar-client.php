<aside>
    <nav class="sidenav">
        <div class="nav-tabs">
            <!-- <?php
            $dashboardLink = ($_SESSION['user_role'] === 'admin') ? 'dashboard.php' : 'dashboard-client.php';
            ?>
            <a href="<?php echo $dashboardLink; ?>">
                <button type="button" class="tab active"><i class="fa-solid fa-house"></i>Dashboard</button>
            </a> -->

            <a href="dashboard-client.php">
                <button type="button" class="tab active"><i class="fa-solid fa-house"></i>Dashboard</button>
            </a>
            <a href="add-website.php">
                <button type="button" class="tab" id="addButton"><i class="fa-solid fa-square-plus"></i>Add
                    Website</button>
            </a>
            <a href="dblist.php">
                <button type="button" class="tab"><i class="fa-solid fa-bars-staggered"></i>DB List</button>
            </a>
            <a href="manage-profile.php">
                <button type="button" class="tab"><i class="fa-solid fa-user"></i>Manage Profile</button>
            </a>
            <h3 style="color:white">Client</h3>
        </div>
        <a type="button" class="logout-btn" id="logout-btn"><i class="fa-solid fa-power-off"></i>Log
            out</a>
    </nav>
</aside>