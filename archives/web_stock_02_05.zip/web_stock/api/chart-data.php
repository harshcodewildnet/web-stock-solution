<?php
// header('Content-Type: application/json');
require '../includes/db.php';

$response = [
    'status' => 'error',
    'message' => '',
    'data' => null
];

try {
    if (!$conn) {
        throw new Exception("Database connection failed.");
    }

    $traffic_ranges = [
        '0-1K' => [0, 1000],
        '1K-10K' => [1001, 10000],
        '10K-50K' => [10001, 50000],
        '50K+' => [50001, PHP_INT_MAX]
    ];

    $da_ranges = [
        '0-10' => [0, 10],
        '11-30' => [11, 30],
        '31-50' => [31, 50],
        '51+' => [51, PHP_INT_MAX]
    ];

    $data = [
        'traffic' => [],
        'category' => [],
        'approval' => [],
        'da' => []
    ];

    // 1. Traffic Ranges
    foreach ($traffic_ranges as $label => [$min, $max]) {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM websites WHERE traffic BETWEEN ? AND ?");
        if (!$stmt) throw new Exception("Query preparation failed for traffic range: $label");
        $stmt->bind_param("ii", $min, $max);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $data['traffic'][$label] = (int)$result['count'];
        $stmt->close();
    }

    // 2. Category Frequency
    $result = $conn->query("SELECT category, COUNT(*) as count FROM websites GROUP BY category");
    if (!$result) throw new Exception("Query failed for category frequency.");
    while ($row = $result->fetch_assoc()) {
        $data['category'][$row['category']] = (int)$row['count'];
    }

    // 3. Approval per Category
    $result = $conn->query("SELECT category, COUNT(*) as count FROM websites WHERE approved = 1 GROUP BY category");
    if (!$result) throw new Exception("Query failed for approval per category.");
    while ($row = $result->fetch_assoc()) {
        $data['approval'][$row['category']] = (int)$row['count'];
    }

    // 4. DA Ranges
    foreach ($da_ranges as $label => [$min, $max]) {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM websites WHERE da BETWEEN ? AND ?");
        if (!$stmt) throw new Exception("Query preparation failed for DA range: $label");
        $stmt->bind_param("ii", $min, $max);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $data['da'][$label] = (int)$result['count'];
        $stmt->close();
    }

    // All good
    $response['status'] = 'success';
    $response['data'] = $data;

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
