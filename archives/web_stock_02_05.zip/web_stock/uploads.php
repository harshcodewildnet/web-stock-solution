<?php
require_once 'includes/auth.php';
requireRole('admin'); // or 'user'
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <title>Resources</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="js/main.js"></script>
    <style>
        .alert {
            padding: 10px 15px;
            margin: 20px 0;
            border: 1px solid transparent;
            border-radius: 4px;
            font-size: 14px;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>

    <!-- Alert Box -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success" id="messageBox">
            <?php echo $_SESSION['success']; ?>
        </div>
        <?php unset($_SESSION['success']); endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger" id="messageBox">
            <?php echo $_SESSION['error']; ?>
        </div>
        <?php unset($_SESSION['error']); endif; ?>

    <!-- Header Dblist-->
    <header>
        <div class="logo">
            <img src="assets/wnet-image.png" alt="WildNet logo">
        </div>
        <div class="search-area">
            <div class="actions">
                <label id="profile-label">
                    <i class="fa-solid fa-user"></i>
                    <button id="profile-toggle">
                        <i class="fa-solid fa-caret-down"></i>
                    </button>
                    <div id="profile-dropdown" class="profile-dropdown">
                        <a href="manage-profile.php" class="dropdown-item">My Profile</a>
                        <hr>
                        <a href="#" class="dropdown-item">Reset Password</a>
                    </div>
                </label>
                <a href="#" id="logout-link">
                    <i class="fa-solid fa-power-off"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </header>

    <!-- SideBar Menu -->
    <?php include 'includes/sidebar-admin.php'; ?>

    <!-- Main Content -->
    <main>
        <div class="top-row">
            <div class="site-count">
                <h2>Uploads</h2>
            </div>
            <a href="#" class="add-user-btn"><i class="fa-solid fa-circle-plus"></i>Add File</a>
        </div>
        <hr>
        <div class="content-area">
            <table class="sitelist">
                <thead>
                    <tr>
                        <th>Category Name</th>
                        <th>Website URL</th>
                        <th>Currency</th>
                        <th>Price</th>
                        <th>Client Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="siteTableBody">
                    <a href="x.com" download="">Link To File</a>
                    
                    <!-- Dynamic rows will be injected via js> -->
                </tbody>
            </table>
        </div>
    </main>

    <!-- Logout alert box -->
    <div id="custom-alert" class="alert-overlay">
        <div class="alert-box">
            <p>Are you sure you want to logout?</p>
            <div class="alert-actions">
                <button id="confirm-logout">Yes</button>
                <button id="cancel-logout">No</button>
            </div>
        </div>
    </div>

</body>

</html>