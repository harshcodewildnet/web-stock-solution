<aside>
    <nav class="sidenav">
        <div class="nav-tabs">
            <a href="dashboard.php" class="tab">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
            <a href="add-website.php" class="tab">
                <i class="fa-solid fa-square-plus"></i> Add Website
            </a>
            <a href="dblist.php" class="tab">
                <i class="fa-solid fa-bars-staggered"></i> DB List
            </a>
            <a href="manage-user.php" class="tab">
                <i class="fa-solid fa-user"></i> Manage User
            </a>
            <a href="manage-profile.php" class="tab">
                <i class="fa-solid fa-user"></i> Profile
            </a>
        </div>
        <a href="#" class="logout-btn" id="logout-btn">
            <i class="fa-solid fa-power-off"></i> Log out
        </a>
    </nav>
</aside>
<!-- Active Link Script -->
<script src="js/main.js"></script>