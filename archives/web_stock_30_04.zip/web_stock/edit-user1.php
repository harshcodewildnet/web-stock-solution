<?php
session_start();
require_once 'includes/auth.php';
requireRole('admin'); // Only admin can access

require_once 'includes/db.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Invalid user ID.";
    header('Location: manage-users.php');
    exit;
}

$user_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM user where user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $userId = $user['user_id'];
    $userEmail = $user['email'];
    $userRole = $user['role'];
    $userStatus = $user['status'];
} else {
    $_SESSION['error'] = "User not found.";
    $stmt->close();
    header('Location: manage-users.php');
    exit;
}

$stmt->close();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit User</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <!-- Header -->
    <!-- <?php require_once 'includes/header.php' ?> -->

    <!-- SideBar Menu -->
    <?php include 'includes/sidebar-admin.php'; ?>

    <!-- Main Content -->
    <main style="padding-top: 0;">
        <div class="top-row">
            <div class="site-count">
                <h2>Edit User</h2>
            </div>
        </div>
        <hr>
        <div class="content-area">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error'];
                unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <h3>User Id : &nbsp;<?php echo htmlspecialchars($userId); ?></h3>

            <form action="process-edit-user.php" method="POST">
                <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($userId); ?>">
                <div class="form-group">
                    <label>Email</label><br>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($userEmail); ?>" required>
                </div>

                <div class="form-group">
                    <label>Role</label><br>
                    <select name="role" required>
                        <option value="user" <?php if ($userRole == 'user')
                            echo 'selected'; ?>>User</option>
                        <option value="admin" <?php if ($userRole == 'admin')
                            echo 'selected'; ?>>Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Status</label><br>
                    <select name="status" required>
                        <option value="active" <?php if ($userStatus == '1')
                            echo 'selected'; ?>>Active</option>
                        <option value="inactive" <?php if ($userStatus == '0')
                            echo 'selected'; ?>>Inactive</option>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit">Update User</button>
                    <a href="manage-users.php">Cancel</a>
                </div>
            </form>
        </div>

    </main>

    <!-- Logout alert box -->
    <div id="custom-alert" class="alert-overlay">
        <div class="alert-box">
            <p>Are you sure you want to logout?</p>
            <div class="alert-actions">
                <button id="confirm-logout">Yes</button>
                <button id="cancel-logout">No</button>
            </div>
        </div>
    </div>

    <!-- Scripts -->

    <!-- Logout Script -->
    <script>
        const logoutBtn = document.getElementById('logout-btn');
        const customAlert = document.getElementById('custom-alert');
        const confirmLogout = document.getElementById('confirm-logout');
        const cancelLogout = document.getElementById('cancel-logout');

        // Show the alert box
        logoutBtn.onclick = () => {
            customAlert.style.display = 'flex';
        };

        // If user confirms logout
        confirmLogout.onclick = () => {
            customAlert.style.display = 'none';
            window.location.href = 'logout.php';
        };

        // If user cancels
        cancelLogout.onclick = () => {
            customAlert.style.display = 'none';
        };
    </script>

</body>

</html>