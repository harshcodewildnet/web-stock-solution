<?php
header('Content-Type: application/json');
require_once '../includes/db.php'; // DB connection

$traffic_ranges = [
    '0-5K' => [0, 5000],
    '5K-10K' => [5001, 10000],
    '10K-50K' => [10001, 15000],
    '50K+' => [15001, PHP_INT_MAX]
];

$da_ranges = [
    '0-10' => [0, 10],
    '11-30' => [11, 30],
    '31-50' => [31, 50],
    '51+' => [51, PHP_INT_MAX]
];

$response = [
    'traffic' => [],
    'category' => [],
    'approval' => [],
    'da' => []
];

// 1. Traffic Range Frequency
foreach ($traffic_ranges as $label => [$min, $max]) {
    $query = $conn->prepare("SELECT COUNT(*) as count FROM websites WHERE traffic BETWEEN ? AND ?");
    $query->bind_param("ii", $min, $max);
    $query->execute();
    $result = $query->get_result()->fetch_assoc();
    $response['traffic'][$label] = $result['count'];
}

// 2. Category Frequency
$result = $conn->query("SELECT category, COUNT(*) as count FROM websites GROUP BY category");
while ($row = $result->fetch_assoc()) {
    $response['category'][$row['category']] = $row['count'];
}

// 3. Approval per Category (only approved)
// $result = $conn->query("SELECT category, COUNT(*) as count FROM websites WHERE approved = 1 GROUP BY category");
// while ($row = $result->fetch_assoc()) {
//     $response['approval'][$row['category']] = $row['count'];
// }

// 4. DA Range Frequency
foreach ($da_ranges as $label => [$min, $max]) {
    $query = $conn->prepare("SELECT COUNT(*) as count FROM websites WHERE da BETWEEN ? AND ?");
    $query->bind_param("ii", $min, $max);
    $query->execute();
    $result = $query->get_result()->fetch_assoc();
    $response['da'][$label] = $result['count'];
}

// Return data as JSON
echo json_encode($response);
