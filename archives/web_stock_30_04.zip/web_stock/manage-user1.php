<?php
session_start();
require_once 'includes/auth.php';
requireRole('admin'); // Only admin can access

require_once 'includes/db.php';

$result = $conn->query("SELECT user_id, email, role, status FROM user");

?>

<!DOCTYPE html>
<html lang="en">
<head>  
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>

<div class="container">
    <h2>Manage Users</h2>

    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>#ID</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($user = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['role']); ?></td>
                    <td><?php echo htmlspecialchars($user['status']); ?></td>
                    <td>
                        <a href="edit-user.php?id=<?php echo $user['user_id']; ?>">Edit</a> |
                        <a href="delete-user.php?id=<?php echo $user['user_id']; ?>" onclick="return confirm('Are you sure?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

</body>
</html>
