<?php
// api/add-website.php
header('Content-Type: application/json');
require_once '../includes/db.php';

$data = json_decode(file_get_contents('php://input'), true);

// Basic validation (you can extend this)
// $required = ['category', 'status', 'currency', 'price', 'client_name', 'blogger_name', 'blogger_email', 'url'];
$required = ['category', 'currency', 'price', 'client_name', 'blogger_name', 'blogger_email', 'spam_score', 'da', 'dr', 'traffic', 'location', 'url', 'added_by'];

foreach ($required as $field) {
    if (empty($data[$field])) {
        echo json_encode(['status' => 'error', 'message' => "Field '$field' is required."]);
        exit;
    }
}

// Prepare and sanitize values
$stmt = $conn->prepare("
    INSERT INTO websites (
        category, url, currency, price, client_name, blogger_name, blogger_email,
        blogger_mobile, spam_score, dr, traffic, da, location, mode, added_by, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "sssisssssiiissss",
    $data['category'],
    $data['url'],
    $data['currency'],
    $data['price'],
    $data['client_name'],
    $data['blogger_name'],
    $data['blogger_email'],
    $data['blogger_mobile'],
    $data['spam_score'],
    $data['dr'],
    $data['traffic'],
    $data['da'],
    $data['location'],
    $data['mode'],
    $data['added_by'],
    $data['status']
);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Website added successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Insert failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
