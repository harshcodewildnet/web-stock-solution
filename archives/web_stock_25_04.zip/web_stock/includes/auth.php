<?php
session_start();

// if (!isset($_SESSION['user_id'])) {
//     header("Location: index.php");
//     exit;
// }
function requireRole($role)
{
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== $role) {
        header("Location: index.php");
        exit;
    }
}
