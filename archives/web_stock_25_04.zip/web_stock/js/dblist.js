document.addEventListener('DOMContentLoaded', () => {
    const applyButton = document.getElementById('apply');
    const clearButton = document.getElementById('clear');
    const tableBody = document.getElementById('siteTableBody');
    const modal = document.getElementById('modal-dialog-common');

    // Helper function to get all checked checkbox values for a given group
    function getCheckedValues(groupClass) {
        const checkboxes = document.querySelectorAll(`.${groupClass}:checked`);
        return Array.from(checkboxes).map(cb => cb.value);
    }

    // Create a filters object from all groups
    function getSelectedFilters() {
        return {
            category: getCheckedValues('category-filter'),
            traffic: getCheckedValues('traffic-filter'),
            location: getCheckedValues('location-filter'),
            da: getCheckedValues('da-filter'),
            dr: getCheckedValues('dr-filter'),
            price: getCheckedValues('price-filter'),
            spam: getCheckedValues('spam-filter'),
            status: getCheckedValues('status-filter'),
            addedby: getCheckedValues('addedby-filter'),
            timeline: getCheckedValues('timeline-filter')
        };
    }

    // Function to send filters to server and update table
    function applyFilters() {
        const filters = getSelectedFilters();

        fetch('api/filter-websites.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(filters)
        })
            .then(response => response.json())
            .then(data => {
                updateTable(data.websites);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    // Update the website table with new rows
    function updateTable(websites) {
        if (!websites || websites.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="7">No websites found.</td></tr>';
            return;
        }

        const rows = websites.map(site => `
            <tr>
                <td>${site.category}</td>
                <td><a href="${site.url}" target="_blank">${site.url}</a></td>
                <td>${site.currency}</td>
                <td>${site.price}</td>
                <td>${site.client_name}</td>
                <td>${site.blogger_email}</td>
                <td class="list-actions">
                    <i class="fa-solid fa-eye view-btn" data-site='${JSON.stringify(site)}'></i>
                    <i class="fa-solid fa-pencil edit-btn" data-site='${JSON.stringify(site)}'></i>
                </td>
            </tr>
        `).join('');

        tableBody.innerHTML = rows;
    }

    // Event: Apply button clicked
    applyButton.addEventListener('click', applyFilters);

    // Event: Clear button clicked
    clearButton.addEventListener('click', () => {
        // Clear all checkboxes
        document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
        // Clear the table
        tableBody.innerHTML = '';
    });

    // Optional: Fetch all data initially
    applyFilters();


    // Attaching Event Listener to tableBody as event delegation for dynamic data
    tableBody.addEventListener('click', (e) => {
        const target = e.target;

        if (target.classList.contains('view-btn')) {
            const data = JSON.parse(target.dataset.site);
            openModal('view', data);
            // populateViewModal(site);
        }

        if (target.classList.contains('edit-btn')) {
            const data = JSON.parse(target.dataset.site);
            openModal('edit', data);
            // populateEditModal(site);
        }
    });

    function openModal(mode, data) {

        // const modal = document.getElementById('modal-dialog-common');

        const fields = [
            'category', 'status', 'currency', 'price', 'client-name',
            'blogger-name', 'blogger-email', 'blogger-mobile',
            'spam-score', 'dr', 'traffic', 'da', 'url',
            'location', 'mode', 'added-by'
        ];

        fields.forEach(key => {
            const input = document.getElementById(`modal-${key}`);
            if (input) input.value = data[key.replace(/-/g, '_')] || '';
        });

        const isView = mode === 'view';
        fields.forEach(key => {
            const input = document.getElementById(`modal-${key}`);
            if (input) input.disabled = isView;
        });

        document.getElementById('modal-title').textContent = isView ? 'View Website' : 'Edit Website';
        document.getElementById('modal-save-btn').style.display = isView ? 'none' : 'inline-block';

        // document.getElementById('modal-dialog-common').classList.add('show');
        modal.classList.add('show');
    }

    // Close modal
    document.getElementById('close-btn').addEventListener('click', () => {
        // document.getElementById('modal-dialog-common').classList.remove('show');
        modal.classList.remove('show');
    });

    window.addEventListener('click', (e) => {
        if (modal === e.target) modal.classList.remove('show');
    })


});
