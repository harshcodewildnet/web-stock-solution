-Forms' Validations- add website, edit website

validations in add website form-
    -price, blogger mob, da, dr, spam, traffic -> type numbers only
    -mob only 10 letters type
added by required on edit website

after update persistence- 
    - status
    - client name

-search result table structure

-forgot password - email, otp
    screens: login -> enter email -> enter otp -> new pass -> (Redirecting) -> login


-filters from backend (later)


remove simple alerts from - add/edit/delete website, add/edit/delete user, upload csv, search websites/users
client-> user
add delete option to admin on dblist
add placeholders on add website/edit Websites
add range validations
table layout on search
add team names in added by filter

pssword change alert

