<?php
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'webstocksite4dem_webstock';

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
