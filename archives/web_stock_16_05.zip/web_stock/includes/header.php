<!-- Header -->
<header>
    <div class="logo">
        <img src="assets/wnet-image.png" alt="WildNet logo">
    </div>
</header>