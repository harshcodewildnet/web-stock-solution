<?php

class Task
{
    private $conn;

    public function __construct($conn)
    {
        $this->con = $conn;
    }

    public function getEmployeeTasks($id)
    {   
        

    }


}