<?php
require_once 'config/config.php';
$result = $conn->query('SELECT e.*, t.* FROM employee e inner join task t on t.emp_id=e.emp_id;');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="assets/js/add.js"></script>
</head>

<body>
    <!-- Header Dblist-->
    <header>
        <a href="dashboard.php">
            <div class="logo">
                <img src="assets/images/wnet-image.png" alt="WildNet logo">
            </div>
        </a>
        <div class="search-area">
            <h3 class="head">Welcome User</h3>
            <div class="actions">
                <label id="profile-label">
                    <i class="fa-solid fa-user"></i>
                    <button id="profile-toggle">
                        <i class="fa-solid fa-caret-down"></i>
                    </button>
                    <div id="profile-dropdown" class="profile-dropdown">
                        <a href="manage-profile.php" class="dropdown-item">My Profile</a>
                        <hr>
                        <a href="manage-profile.php" class="dropdown-item">Reset Password</a>
                    </div>
                </label>
                <a href="#" id="logout-link">
                    <i class="fa-solid fa-power-off"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </header>
    <aside>
        <nav class="sidenav">
            <div class="nav-tabs">
                <a href="index.php" class="tab">
                    <i class="fa-solid fa-house"></i> Home
                </a>
                <!-- <a href="manage-user.php" class="tab">
                    <i class="fa-solid fa-user"></i> Manage User
                </a> -->
                <a href="profile.php" class="tab">
                    <i class="fa-solid fa-user"></i> My Account
                </a>
            </div>
        </nav>
    </aside>
    <main>
        <!-- top panel -->
        <!-- <div class="top-panel">
            Filter Boxes
            <div class="filler"></div>
            <div class="details-card">
                <h4 class="card-title">Quick Analysis</h4>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-leaf"></i></span>
                    <span class="label">Total leaves -</span>
                    <span class="value">0</span>
                </div>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-calendar-days"></i></span>
                    <span class="label green">Total days -</span>
                    <span class="value">22</span>
                </div>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-square-plus"></i></span>
                    <span class="label blue">Gross Hours -</span>
                    <span class="value">176h22m</span>
                </div>
            </div>
        </div> -->
        <!-- content -->
        <div class="content-area">
            <div class="table-wrapper">
                <table class="sitelist">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Working/Leave</th>
                            <th>Nature of Task</th>
                            <th>Task Brief</th>
                            <th>Time Taken</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="siteTableBody">

                        <?php
                        if ($result->num_rows > 0) {
                            while ($task = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?= $task['date'] ?></td>
                                    <!-- <td><?= $task['name'] ?></td> -->
                                    <td>
                                        <!-- <select name="">
                                            <option value="">Working</option>
                                            <option value="">Leave</option>
                                        </select> -->
                                        Working
                                    </td>
                                    <td><?= $task['category'] ?></td>
                                    <td><?= $task['description'] ?></td>
                                    <td>
                                        <!-- <select name="time" id="time">
                                            <option value="">0:30</option>
                                            <option value="">1:00</option>
                                            <option value="">1:30</option>
                                            <option value="">2:00</option>
                                            <option value="">2:30</option>
                                        </select> -->
                                        <?= $task['duration'] ?>
                                    </td>
                                    <td>
                                        <select name="status" id="status">
                                            <option value="" selected>Approved</option>
                                            <option value="" <?= ($task['status'] == '1') ? '' : 'selected' ?>>Not Approved
                                            </option>
                                        </select>
                                        <?= ($task['status'] == '1') ? 'Approved' : 'Not Approved' ?>
                                    </td>
                                    <td>-</td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                        <tr class="entry-row">
                            <td><input type="date"></td>
                            <td>
                                <select name="">
                                    <option value="">Working</option>
                                    <option value="">Leave</option>
                                </select>
                            </td>
                            <td><input type="text" placeholder="Enter Task Category"></td>
                            <td><input type="text" placeholder="Enter Task Description"></td>
                            <td>
                                <select name="time" id="time">
                                    <option value="">0:30</option>
                                    <option value="">1:00</option>
                                    <option value="">1:30</option>
                                    <option value="">2:00</option>
                                    <option value="">2:30</option>
                                </select>
                            </td>
                            <td>
                                <select name="status" id="status" disabled>
                                    <option value="0" selected>Not Approved</option>
                                    <option value="1">Approved</option>
                                </select>
                            </td>
                            <td><i class="fa-regular fa-trash-can"></i></td>
                        </tr>
                        <!-- <tr class="add-btn-row">
                            <td colspan="7">
                                <button class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
                            </td>
                        </tr> -->
                    </tbody>
                </table>
                <div class="actions">
                    <button id="submit-btn" class="add-btn">Submit</button>
                    <button id="add-btn" class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
                </div>
            </div>
            <div class="bottom-panel">
                <div class="left">
                    <canvas id="trafficChart"></canvas>
                </div>
                <div class="right"></div>
            </div>
        </div>
    </main>
    <!-- <footer></footer> -->
    <script src="assets/js/filters.js"></script>
    <!-- Graphs Script -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>


        window.onload = function () {
            var chart = new CanvasJS.Chart("chartContainer",
                {
                    title: {
                        text: "Spline Area Chart"
                    },
                    axisY: {
                        title: "Units Sold",
                        valueFormatString: "#0,,.",
                        suffix: " m"
                    },
                    data: [
                        {
                            toolTipContent: "{y} units",
                            type: "splineArea",
                            showInLegend: true,
                            legendText: "source: Nielsen SoundScan",
                            markerSize: 5,
                            color: "rgba(54,158,173,.7)",
                            dataPoints: [
                                { x: new Date(1992, 0), y: 2506000 },
                                { x: new Date(1993, 0), y: 2798000 },
                                { x: new Date(1994, 0), y: 3386000 },
                                { x: new Date(1995, 0), y: 6944000 },
                                { x: new Date(1996, 0), y: 6026000 },
                                { x: new Date(1997, 0), y: 2394000 },
                                { x: new Date(1998, 0), y: 1872000 },
                                { x: new Date(1999, 0), y: 2140000 },
                                { x: new Date(2000, 0), y: 7289000, indexLabel: "highest" },
                                { x: new Date(2001, 0), y: 4830000 },
                                { x: new Date(2002, 0), y: 2009000 },
                                { x: new Date(2003, 0), y: 2840000 },
                                { x: new Date(2004, 0), y: 2396000 },
                                { x: new Date(2005, 0), y: 1613000 },
                                { x: new Date(2006, 0), y: 2821000 },
                                { x: new Date(2007, 0), y: 2000000 },
                                { x: new Date(2008, 0), y: 1397000 }
                            ]
                        }
                    ]
                });

            chart.render();
        }




        // new Chart(document.getElementById('trafficChart'), {
        //     data: {
        //         datasets: [
        //             {
        //                 fill: {
        //                     target: 'origin',
        //                     above: 'rgb(255, 0, 0)',   // Area will be red above the origin
        //                     below: 'rgb(0, 0, 255)'    // And blue below the origin
        //                 }
        //             }
        //         ]
        //     }
        // });

        // new Chart(ctx, {
        //     data: {
        //         datasets: [
        //             { fill: 'origin' },      // 0: fill to 'origin'
        //             { fill: '+2' },          // 1: fill to dataset 3
        //             { fill: 1 },             // 2: fill to dataset 1
        //             { fill: false },         // 3: no fill
        //             { fill: '-2' },          // 4: fill to dataset 2
        //             { fill: { value: 25 } }    // 5: fill to axis value 25
        //         ]
        //     }
        // });

    </script>
</body>

</html>