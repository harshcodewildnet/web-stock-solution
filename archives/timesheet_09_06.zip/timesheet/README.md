Modules: 
1) Admin
2) Login/Registration
3) Task
4) Report
5) Email/Notification

Entity Hierarchy:
Super Admin
    -HR: 
    -HOD: 
        -RM: team members details
            -Executive
