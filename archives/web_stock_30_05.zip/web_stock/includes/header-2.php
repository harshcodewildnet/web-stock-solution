<!-- Header dblist -->
<header>
    <div class="logo">
        <img src="assets/wnet-image.png" alt="WildNet logo">
    </div>
    <div class="search-area">
        <select name="serach-cat" id="search-cat" required>
            <option value="" selected disabled hidden>Search By</option>
            <option value="cat1">Name</option>
            <option value="cat2">URL</option>
            <option value="cat3">Domain</option>
        </select>
        <input type="text" class="search-text" placeholder="Search for a website">
    </div>
</header>