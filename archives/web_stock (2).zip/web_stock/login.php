<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Mode</title>
    <link rel="stylesheet" href="css/login1.css">
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="assets/wnet-image.png" alt="Logo">
        </div>
        <div class="login-box">
            <div class="form-container">
                <h3 class="head">Login To Your Account</h3>
                <form action="login.php" method="POST">
                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" name="email" id="email" placeholder="Enter email" required>
                    </div>
                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" id="password" placeholder="Enter Password" required>
                    </div>
                    <div class="form-group">
                        <label for="role" class="form-label">Login As</label>
                        <select name="role" id="role" required>
                            <option value="">Select Role</option>
                            <option value="admin">Admin</option>
                            <option value="client">Client</option>
                        </select>
                    </div>
                    <div class="check-option">
                        <input type="checkbox" name="remember" id="remember">
                        <label for="remember">Remember Me</label>
                    </div>
                    <button type="submit" class="login-btn">Login</button>
                    <a href="#" class="forgot-password">Forgot Password?</a>
                </form>
            </div>
        </div>
    </div>
    <footer></footer>
</body>

</html>
