<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';

require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Reader\Exception as ReaderException;

if (isset($_POST['submit'])) {
    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error'] = "No file uploaded or upload failed.";
        header("Location: ../uploads.php");
        exit;
    }

    $file = $_FILES['csv_file'];
    $originalFilename = basename($file['name']);
    $fileType = strtolower(pathinfo($originalFilename, PATHINFO_EXTENSION));
    $tempPath = $file['tmp_name'];
    $uploadDir = "../uploads/";
    $targetPath = $uploadDir . $originalFilename;

    if (!in_array($fileType, ['csv', 'xls', 'xlsx'])) {
        $_SESSION['error'] = "Only CSV, XLS, and XLSX files are allowed.";
        header("Location: ../uploads.php");
        exit;
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        $_SESSION['error'] = "File size exceeds 5MB limit.";
        header("Location: ../uploads.php");
        exit;
    }

    // Generate unique filename
    $uniqueName = uniqid('upload_', true) . '.' . $fileType;
    $targetPath = $uploadDir . $uniqueName;


    // $stmt = $conn->prepare("SELECT * FROM uploads WHERE filename = ?");
    // $stmt->bind_param("s", $originalFilename);
    // $stmt->execute();
    // if ($stmt->get_result()->num_rows > 0) {
    //     $_SESSION['error'] = "This file is already uploaded.";
    //     header("Location: ../uploads.php");
    //     exit;
    // }

    $expectedHeader = [
        'Category',
        'Url',
        'Currency',
        'Price',
        'Client Name',
        'Blogger Name',
        'Blogger Email',
        'Blogger Mobile',
        'Spam Score',
        'DR',
        'Traffic',
        'DA',
        'Location',
        'Added By'
    ];

    try {
        $reader = ($fileType === 'csv')
            ? IOFactory::createReader('Csv')
            : IOFactory::createReaderForFile($tempPath);

        if ($reader instanceof \PhpOffice\PhpSpreadsheet\Reader\Csv) {
            $reader->setDelimiter(',');
            $reader->setEnclosure('"');
        }

        $spreadsheet = $reader->load($tempPath);
        $data = $spreadsheet->getActiveSheet()->toArray();
    } catch (ReaderException $e) {
        $_SESSION['error'] = "Error reading file: " . $e->getMessage();
        header("Location: ../uploads.php");
        exit;
    }

    $header = array_map('trim', $data[0]);
    if ($header !== $expectedHeader) {
        $_SESSION['error'] = "Invalid headers. Use the official CSV template.";
        header("Location: ../uploads.php");
        exit;
    }

    $stmtInsert = $conn->prepare("INSERT INTO websites (
        category, url, currency, price, client_name, blogger_name,
        blogger_email, blogger_mobile, spam_score, dr, traffic, da,
        location, mode, added_by, date_added
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CSV Upload', ?, NOW())");

    if ($stmtInsert === false) {
        $_SESSION['error'] = "DB error (prepare): " . $conn->error;
        header("Location: ../uploads.php");
        exit;
    }

    $lineNum = 2;
    $rowCount = 0;
    $errorCount = 0;
    $invalidRows = [];
    $rowsToInsert = [];

    $nameRegex = "/^[A-Za-z\s]+$/";
    $emailRegex = "/^[^\s@]+@[^\s@]+\.[^\s@]+$/";
    $mobileRegex = "/^\+?\d{10,15}$/";
    $urlRegex = "~^(https?:\/\/)?[\w\-]+(\.[\w\-]+)+[\/#?]?.*$~i";

    $validCategories = ['General', 'Technology', 'Travel', 'Food & Recipes', 'Lifestyle', 'Education', 'Business & Marketing', 'Finance', 'News & Politics', 'Health & Fitness', 'Entertainment', 'Gaming', 'Fashion', 'DIY & Home'];

    $validCurrencies = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD', 'NZD', 'CNY', 'INR', 'KRW', 'RUB', 'BR L', 'ZAR', 'SGD', 'HKD', 'SEK', 'NOK', 'DKK', 'MXN', 'TRY', 'THB', 'IDR', 'MYR', 'PHP', 'AED'];

    $validLocations = ['Global', 'United States', 'United Kingdom', 'France', 'Germany', 'Netherlands', 'Italy', 'Japan', 'Switzerland', 'Canada', 'Australia', 'New Zealand', 'China', 'India', 'South Korea', 'Russia', 'Brazil', 'South Africa', 'Singapore', 'Hong Kong', 'Sweden', 'Norway', 'Denmark', 'Mexico', 'Turkey', 'Thailand', 'Indonesia', 'Malaysia', 'Philippines', 'United Arab Emirates'];

    $requiredFields = [
        0 => 'Category',
        1 => 'Url',
        2 => 'Currency',
        3 => 'Price',
        5 => 'Blogger Name',
        6 => 'Blogger Email',
        8 => 'Spam Score',
        9 => 'DR',
        10 => 'Traffic',
        11 => 'DA',
        12 => 'Location',
        13 => 'Added By'
    ];

    function validateRange($value, $min, $max, $fieldName)
    {
        if (!is_numeric($value))
            return "$fieldName must be a number.";
        if ($value < $min || $value > $max)
            return "$fieldName must be between $min and $max.";
        return '';
    }

    for ($i = 1; $i < count($data); $i++) {
        $row = array_map('trim', $data[$i]);
        if (count(array_filter($row)) === 0)
            continue;
        if (count($row) !== count($expectedHeader)) {
            $invalidRows[] = "Line $lineNum: Incorrect number of columns.";
            $errorCount++;
            $lineNum++;
            continue;
        }

        $fieldErrors = [];
        foreach ($requiredFields as $index => $name) {
            if (!isset($row[$index]) || $row[$index] === '') {
                $fieldErrors[] = "$name is required.";
            }
        }


        // Validation checks as before...

        if (!in_array($row[0], $validCategories))
            $fieldErrors[] = "Invalid Category.";
        if (!in_array($row[2], $validCurrencies))
            $fieldErrors[] = "Invalid Currency.";
        if (!in_array($row[12], $validLocations))
            $fieldErrors[] = "Invalid Location.";

        if (isset($row[5]) && !preg_match($nameRegex, $row[5]))
            $fieldErrors[] = "Blogger Name must only contain letters and spaces.";
        if (isset($row[6]) && !preg_match($emailRegex, $row[6]))
            $fieldErrors[] = "Invalid Blogger Email.";
        if (!empty($row[7]) && !preg_match($mobileRegex, $row[7]))
            $fieldErrors[] = "Blogger Mobile must be 10-15 digits and may start with +.";
        if (!empty($row[1]) && !preg_match($urlRegex, $row[1]))
            $fieldErrors[] = "Invalid URL.";

        $rangeChecks = [
            [3, 1, 1000, 'Price'],
            [8, 1, 100, 'Spam Score'],
            [9, 1, 100, 'DR'],
            [10, 1, 10000, 'Traffic'],
            [11, 1, 100, 'DA']
        ];

        foreach ($rangeChecks as [$index, $min, $max, $name]) {
            if (!empty($row[$index])) {
                $msg = validateRange($row[$index], $min, $max, $name);
                if ($msg)
                    $fieldErrors[] = $msg;
            }
        }

        if (!empty($fieldErrors)) {
            $invalidRows[] = "Line $lineNum: " . implode("; ", $fieldErrors);
            $errorCount++;
            $lineNum++;
            continue;
        }

        $rowsToInsert[] = ['data' => $row, 'line' => $lineNum];
        $lineNum++;
    }

    if ($errorCount > 0) {
        $_SESSION['error'] = "$errorCount row(s) had errors:<br>" . implode("<br>", $invalidRows);
        header("Location: ../uploads.php");
        exit;
    }

    foreach ($rowsToInsert as $rowInfo) {
        $data = $rowInfo['data'];
        $insertLine = $rowInfo['line'];

        $stmtInsert->bind_param("sssdssssddddss", ...$data);

        try {
            if ($stmtInsert->execute()) {
                $rowCount++;
            }
        } catch (mysqli_sql_exception $e) {
            $errorMessage = "Line $insertLine: ";
            $errorMessage .= ($e->getCode() == 1062)
                ? "Duplicate entry detected. This row conflicts with existing data."
                : "Database error (Code: {$e->getCode()}).";

            $_SESSION['error'] = $errorMessage;
            header("Location: ../uploads.php");
            exit;
        }
    }

    $stmtInsert->close();

    if (!is_dir($uploadDir))
        mkdir($uploadDir, 0777, true);
    if (!move_uploaded_file($tempPath, $targetPath)) {
        $_SESSION['error'] = "Rows inserted but failed to move uploaded file.";
        header("Location: ../uploads.php");
        exit;
    }

    try {
        $stmt = $conn->prepare("INSERT INTO uploads (filename, original_name) VALUES (?, ?)");
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("ss", $uniqueName, $originalFilename);
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Upload record failed: " . $e->getMessage();
        header("Location: ../uploads.php");
        exit;
    }

    $conn->close();

    $_SESSION['success'] = "$rowCount row(s) imported and file uploaded successfully.";
    header("Location: ../uploads.php");
    exit;
}
