// Active Link Script 
document.addEventListener('DOMContentLoaded', function () {
    const currentPage = window.location.pathname.split('/').pop();
    const tabs = document.querySelectorAll('.nav-tabs a');

    tabs.forEach(tab => {
        if (tab.getAttribute('href') === currentPage) {
            tab.classList.add('active');
        }
    });
});

// Profile Dropdown Toggle
document.addEventListener('DOMContentLoaded', () => {
    const profileToggle = document.getElementById('profile-toggle');
    const profileDropdown = document.getElementById('profile-dropdown');
    // Toggle dropdown on click 
    profileToggle.addEventListener('click', (e) => {
        e.preventDefault(); // prevent form submission if inside a form 
        profileDropdown.classList.toggle('active');
        e.stopPropagation(); // prevent event from reaching document 
    });
    // Close dropdown if clicked outside 
    document.addEventListener('click', (e) => {
        if (!profileDropdown.contains(e.target) && e.target !== profileToggle) {
            profileDropdown.classList.remove('active');
        }
    });
});

// Logout Script
// document.addEventListener('DOMContentLoaded', () => {
//     const logoutBtn = document.getElementById('logout-link');
//     const alertBox = document.getElementById('alert-box-logout');
//     const logOutAlert = document.getElementById('custom-alert');
//     const confirmLogout = document.getElementById('confirm-logout');
//     const cancelLogout = document.getElementById('cancel-logout');

//     logoutBtn.onclick = (e) => {
//         e.preventDefault();
//         logOutAlert.style.display = 'flex';
//     };

//     confirmLogout.onclick = () => {
//         logOutAlert.style.display = 'none';
//         window.location.href = 'logout.php';
//     };

//     cancelLogout.onclick = () => {
//         logOutAlert.style.display = 'none';
//     };

//     document.addEventListener('click', (e) => {
//         if (logOutAlert.style.display === 'flex') {
//             if (!alertBox.contains(e.target) && !logoutBtn.contains(e.target)) {
//                 logOutAlert.style.display = 'none';
//             }
//         }
//     });
// });




document.addEventListener('DOMContentLoaded', () => {
    const alertOverlay = document.getElementById('custom-alert');
    const alertBox = document.getElementById('alert-box');
    const alertMessage = document.getElementById('alert-message');
    const confirmBtn = document.getElementById('alert-confirm-btn');
    const cancelBtn = document.getElementById('alert-cancel-btn');

    let confirmCallback = null;
    let cancelCallback = null;

    function showAlert(message, onConfirm, onCancel = null, confirmText = 'Confirm', cancelText = 'Cancel') {

        alertMessage.textContent = message;
        confirmBtn.textContent = confirmText;
        cancelBtn.textContent = cancelText;

        confirmCallback = onConfirm;
        cancelCallback = onCancel;

        alertOverlay.style.display = 'flex';
        console.log('show alert called');

    }

    confirmBtn.onclick = () => {
        alertOverlay.style.display = 'none';
        if (confirmCallback) confirmCallback();
    };

    cancelBtn.onclick = () => {
        alertOverlay.style.display = 'none';
        if (cancelCallback) cancelCallback();
    };

    // document.addEventListener('click', (e) => {
    //     if (alertOverlay.style.display === 'flex' && !alertBox.contains(e.target)) {
    //         alertOverlay.style.display = 'none';
    //     }
    // });

    // Make showAlert globally available
    window.showAlert = showAlert;


});


document.getElementById('logout-link').addEventListener('click', (e) => {
    e.preventDefault();
    console.log('button cliked');

    showAlert('Are you sure you want to logout?', () => {
        window.location.href = 'logout.php';
    }, null, 'Logout', 'Cancel');
});


function showMessage(message, isSuccess, redirectUrl = null, delay = 2000) {
    const box = document.getElementById('messageBox');
    const icon = document.getElementById('alertIcon');
    const text = document.getElementById('alertMessage');

    text.textContent = message;

    box.className = isSuccess ? 'alert alert-success' : 'alert alert-danger';
    icon.className = isSuccess ? 'fa-solid fa-circle-check' : 'fa-solid fa-circle-exclamation';

    box.style.display = 'flex';

    setTimeout(() => {
        // box.style.display = 'none';

        if (redirectUrl) {
            window.location.href = redirectUrl;
        }
    }, delay);

}