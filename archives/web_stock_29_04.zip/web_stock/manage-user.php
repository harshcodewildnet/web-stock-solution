<?php
session_start();
require_once 'includes/auth.php';
requireRole('admin'); // Only admin can access

require_once 'includes/db.php';

$result = $conn->query("SELECT user_id, email, role, status FROM user where role = 'user' ");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Dashboard</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <!-- Header -->
    <!-- <?php require_once 'includes/header.php' ?> -->

    <!-- SideBar Menu -->
    <?php include 'includes/sidebar-admin.php'; ?>

    <!-- Main Content -->
    <main style="padding-top: 0;">
        <div class="top-row">
            <div class="site-count">
                <h4>Total Users :</h4>
                <h2><?php echo $result->num_rows; ?></h2>
            </div>
            <a href="add-user.php" class="add-user-btn">Add User</a>
        </div>
        <hr>
        <!-- Content Area -->
        <div class="content-area">
            <div class="table-wrapper">
                <table class="sitelist userlist" style="width: 100%; margin: auto;">
                    <thead>
                        <tr>
                            <th>S. No.</th>
                            <th>User Id</th>
                            <th>User Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php while ($user = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <!-- <td><?php echo htmlspecialchars($user['role']); ?></td> -->
                                <td><?php echo htmlspecialchars($user['role']); ?></td>
                                <td><?php echo htmlspecialchars($user['status']) == 1 ? 'active' : 'inactive'; ?></td>
                                <td>
                                    <a href="edit-user.php?id=<?php echo $user['user_id']; ?>"><i
                                            class="fa-solid fa-pencil"></i></a>&nbsp;&nbsp;|&nbsp;&nbsp;
                                    <a href="delete-user.php?id=<?php echo $user['user_id']; ?>"
                                        onclick="return confirm('Are you sure?');"><i class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Logout alert box -->
    <div id="custom-alert" class="alert-overlay">
        <div class="alert-box">
            <p>Are you sure you want to logout?</p>
            <div class="alert-actions">
                <button id="confirm-logout">Yes</button>
                <button id="cancel-logout">No</button>
            </div>
        </div>
    </div>

    <!-- Scripts -->

    <!-- Logout Script -->
    <script>
        const logoutBtn = document.getElementById('logout-btn');
        const customAlert = document.getElementById('custom-alert');
        const confirmLogout = document.getElementById('confirm-logout');
        const cancelLogout = document.getElementById('cancel-logout');

        // Show the alert box
        logoutBtn.onclick = () => {
            customAlert.style.display = 'flex';
        };

        // If user confirms logout
        confirmLogout.onclick = () => {
            customAlert.style.display = 'none';
            window.location.href = 'logout.php';
        };

        // If user cancels
        cancelLogout.onclick = () => {
            customAlert.style.display = 'none';
        };
    </script>

</body>

</html>