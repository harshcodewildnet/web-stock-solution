// Active Link Script 
document.addEventListener('DOMContentLoaded', function () {
    const currentPage = window.location.pathname.split('/').pop();
    const tabs = document.querySelectorAll('.nav-tabs a');

    tabs.forEach(tab => {
        if (tab.getAttribute('href') === currentPage) {
            tab.classList.add('active');
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {
    const profileDropdown = document.getElementById('profile-dropdown');
    const profileToggle = this.getElementById('profile-toggle');

    profileToggle.addEventListener('click' , () => {
        profileDropdown.classList.toggle('active');
    });

    window.addEventListener('click', () => {
        profileDropdown.classList.toggle('active');
    });

});
