ReadMe for Web_Stock Project

-dynamic link active
-add website error
-redirect issues:
    -manage user -> dashboard
    -add-website -> logout




Functionalities Pending:
-Search website
-Search user
-Activate/deactivate user
-add/edit user
-manage profile 
-Pagination
-Graph Data
-Forms' Validations- add website, edit website
-import website data in csv
-edit website
-add name field to users


Graphs to show-
1. Traffic - Bar (Range/Frequency)
2. Category - Donut (Category/Frequency)
3. Approval - Bar(Category/Frequency)
4. DA Range - Bar(Range/Frequency)




select count(category) as category_count, category from websites group by category;
