<?php
session_start();
require_once 'includes/auth.php';
requireRole('admin'); // Only admin can access

require_once 'includes/db.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Invalid user ID.";
    header('Location: manage-users.php');
    exit;
}

$user_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM user where user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $userId = $user['user_id'];
    $userEmail = $user['email'];
    $userRole = $user['role'];
    $userStatus = $user['status'];

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Dashboard</title>
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <!-- Header -->
    <!-- <?php require_once 'includes/header.php' ?> -->

    <!-- SideBar Menu -->
    <?php include 'includes/sidebar-admin.php'; ?>

    <!-- Main Content -->
    <main style="padding-top: 0;">
        <div class="top-row">
            <div class="site-count">
                <h4>Total Users :</h4>
                <h2><?php echo $result->num_rows; ?></h2>
            </div>
            <a href="add-user.php" class="add-user-btn">Add User</a>
        </div>
        <hr>
        <div class="container">
            <h2>Edit User</h2>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error'];
                unset($_SESSION['error']); ?></div>
            <?php endif; ?>

            <form action="process-edit-user.php" method="POST">
                <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_id); ?>">

                <div>
                    <label>Name</label><br>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                </div>

                <div>
                    <label>Email</label><br>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>

                <div>
                    <label>Role</label><br>
                    <select name="role" required>
                        <option value="user" <?php if ($role == 'user')
                            echo 'selected'; ?>>User</option>
                        <option value="admin" <?php if ($role == 'admin')
                            echo 'selected'; ?>>Admin</option>
                    </select>
                </div>

                <div style="margin-top: 20px;">
                    <button type="submit">Update User</button>
                    <a href="manage-users.php">Cancel</a>
                </div>
            </form>
        </div>

    </main>

    <!-- Logout alert box -->
    <div id="custom-alert" class="alert-overlay">
        <div class="alert-box">
            <p>Are you sure you want to logout?</p>
            <div class="alert-actions">
                <button id="confirm-logout">Yes</button>
                <button id="cancel-logout">No</button>
            </div>
        </div>
    </div>

    <!-- Scripts -->

    <!-- Active Link Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // const currentPage = window.location.pathname.split('/').pop();
            const tabs = document.querySelectorAll('.nav-tabs a');

            tabs.forEach(tab => {
                if (tab.getAttribute('href') === 'manage-user.php') {
                    tab.classList.add('active');
                }
            });
        });
    </script>

    <!-- Logout Script -->
    <script>
        const logoutBtn = document.getElementById('logout-btn');
        const customAlert = document.getElementById('custom-alert');
        const confirmLogout = document.getElementById('confirm-logout');
        const cancelLogout = document.getElementById('cancel-logout');

        // Show the alert box
        logoutBtn.onclick = () => {
            customAlert.style.display = 'flex';
        };

        // If user confirms logout
        confirmLogout.onclick = () => {
            customAlert.style.display = 'none';
            window.location.href = 'logout.php';
        };

        // If user cancels
        cancelLogout.onclick = () => {
            customAlert.style.display = 'none';
        };
    </script>

</body>

</html>