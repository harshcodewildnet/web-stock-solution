<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../css/login1.css">
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="../assets/wnet-image.png" alt="">
        </div>
        <div class="login-box">
            <div class="form-container">
                <h3 class="head">Login To Your Account</h3>
                <form id="loginForm" action="../api/login.php" method="POST" novalidate>

                    <!-- Hidden Input for Role -->
                    <input type="hidden" name="role" value="admin">

                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" name="email" id="email" placeholder="Enter email" required>
                        <small class="error" style="color:red;display:none;">Please enter a valid email.</small>
                    </div>

                    <div class="form-group">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" name="password" id="password" placeholder="Enter Password" minlength="6"
                            required>
                        <small class="error" style="color:red;display:none;">Password must be at least 6
                            characters.</small>
                    </div>

                    <div class="check-option">
                        <input type="checkbox" name="remember" id="remember">
                        <label for="remember">Remember Me</label>
                    </div>

                    <button type="submit" class="login-btn">Login</button>
                    <a href="#" class="forgot-password">Forgot Password</a>
                </form>
            </div>
        </div>
    </div>
    <footer></footer>

    <!-- <script>
        document.getElementById('loginForm').addEventListener('submit', function (e) {
            let valid = true;

            // Email validation
            const email = document.getElementById('email');
            const emailError = email.nextElementSibling;
            const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            if (!email.value.match(emailPattern)) {
                emailError.style.display = 'block';
                valid = false;
            } else {
                emailError.style.display = 'none';
            }

            // Password validation
            const password = document.getElementById('password');
            const passwordError = password.nextElementSibling;
            if (password.value.length < 6) {
                passwordError.style.display = 'block';
                valid = false;
            } else {
                passwordError.style.display = 'none';
            }

            if (!valid) {
                e.preventDefault(); // Stop form submission if validation fails
            }
        });
    </script> -->

</body>

</html>