<?php
require_once 'includes/auth.php';
requireRole('user');
?>