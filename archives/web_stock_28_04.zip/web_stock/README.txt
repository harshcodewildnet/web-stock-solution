ReadMe for Web_Stock Project

-dynamic link active
-add website error
-redirect issues:
    -manage user -> dashboard
    -add-website -> logout




Functionalities Pending:
-Search website
-Search user
-Activate/deactivate user
-add/edit user
-manage profile 
-Pagination
-Graph Data
