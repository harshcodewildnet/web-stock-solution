fetch('api/chart-data.php')
    .then(res => res.json())
    .then(response => {
        if (response.status !== 'success') {
            throw new Error(response.message || 'Unknown error from server');
        }

        const data = response.data;
        
        // Chart.defaults.font = {
        //     size: 13,
        //     weight: '500'
        // };

        // Chart.defaults.plugins.legend.labels = {
        //     font: {
        //         size: 14,
        //         weight: 'bold'
        //     }
        // };

        // Chart.defaults.plugins.title = {
        //     font: {
        //         size: 16,
        //         weight: 'bold'
        //     }
        // };


        // 1. Traffic Chart
        if (data.traffic) {

            new Chart(document.getElementById('trafficChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.traffic),
                    datasets: [{
                        label: 'Websites by Traffic Range',
                        data: Object.values(data.traffic),
                        backgroundColor: 'rgba(75, 192, 192, 0.7)'
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: 0,
                            max: 35,
                            ticks: {
                                stepSize: 5
                            },
                            title: {
                                display: true,
                                text: 'No of Websites'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Range in Thousands'
                            }
                        }
                    }
                }
            });
        }

        // 2. Category Chart
        if (data.category) {
            new Chart(document.getElementById('categoryChart'), {
                type: 'doughnut',
                data: {
                    labels: Object.keys(data.category),
                    datasets: [{
                        data: Object.values(data.category),
                        backgroundColor: ['#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0', '#9966FF']
                    }]
                },
                options: {
                    maintainAspectRatio: false
                }
            });
        }

        // 3. Approval Chart
        if (data.approval) {
            new Chart(document.getElementById('approvalChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.approval),
                    datasets: [{
                        label: 'Approved Websites',
                        data: Object.values(data.approval),
                        backgroundColor: 'rgba(153, 102, 255, 0.7)'
                    }]
                },
                options: {
                    maintainAspectRatio: false
                }
            });
        }

        // 4. DA Chart
        if (data.da) {
            new Chart(document.getElementById('daChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.da),
                    datasets: [{
                        label: 'Websites by DA Range',
                        data: Object.values(data.da),
                        backgroundColor: 'rgba(255, 159, 64, 0.7)'
                    }]
                },
                options: {
                    maintainAspectRatio: false
                }
            });
        }
    })
    .catch(err => {
        console.error('Error fetching chart data:', err);
        alert("Failed to load chart data: " + err.message);
    });