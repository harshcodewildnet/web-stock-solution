<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'timesheet');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', 'localost/timesheet/');
define('IMAGE_UPLOAD_PATH', BASE_URL . 'localost/timesheet/');

