
// Filter Script

const filters = document.querySelectorAll('.filter-multiselect');

filters.forEach(filter => {
    const selectBox = filter.querySelector('.select-box');
    const options = filter.querySelector('.options');

    // Toggle dropdown
    selectBox.addEventListener('click', (e) => {
        e.stopPropagation();

        if (filter.classList.contains('active')) {
            filter.classList.remove('active');
            return;
        }

        filters.forEach(f => {
            if (f !== filter) f.classList.remove('active');
        });

        filter.classList.add('active');
    });

    if (options) {
        options.addEventListener('click', e => e.stopPropagation());
    }
});

// Close all on outside click
window.addEventListener('click', () => {
    filters.forEach(filter => {
        filter.classList.remove('active');
    });
});


// Select All Checkbox Script
document.querySelectorAll('.select-all').forEach(selectAllCheckbox => {
    selectAllCheckbox.addEventListener('change', function () {
        const container = this.closest('.filter-multiselect');
        const checkboxes = container.querySelectorAll('input[type="checkbox"]:not(.select-all)');
        checkboxes.forEach(cb => cb.checked = this.checked);
    });
});

// Sync "Select All" when individual checkboxes are changed
document.querySelectorAll('.filter-option').forEach(option => {
    option.addEventListener('change', function () {
        const container = this.closest('.filter-multiselect');
        const allCheckboxes = container.querySelectorAll('.filter-option');
        const allChecked = Array.from(allCheckboxes).every(cb => cb.checked);
        container.querySelector('.select-all').checked = allChecked;
    });
});