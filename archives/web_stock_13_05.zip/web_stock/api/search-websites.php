<?php
header('Content-Type: application/json');
require_once '../includes/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$query = trim($data['query'] ?? '');

if (empty($query)) {
    echo json_encode(['status' => 'error', 'message' => 'Query is required']);
    exit;
}

$like = '%' . $query . '%';

$stmt = $conn->prepare("
    SELECT * FROM websites 
    WHERE url LIKE ? 
       OR client_name LIKE ? 
       OR blogger_email LIKE ?
");

$stmt->bind_param("sss", $like, $like, $like);
$stmt->execute();
$result = $stmt->get_result();

$websites = [];
while ($row = $result->fetch_assoc()) {
    $websites[] = $row;
}

echo json_encode([
    'status' => 'success',
    'count' => count($websites),
    'websites' => $websites
]);

$stmt->close();
$conn->close();
