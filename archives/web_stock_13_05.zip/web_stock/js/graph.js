
document.addEventListener('DOMContentLoaded', () => {
    const applyButton = document.getElementById('apply');
    const clearButton = document.getElementById('clear');
    const websiteCount = document.getElementById('website-count');
    let trafficChartInstance = null;
    let categoryChartInstance = null;
    let approvalChartInstance = null;
    let daChartInstance = null;


    // Helper function to get all checked checkbox values for a given group
    function getCheckedValues(groupClass) {
        const checkboxes = document.querySelectorAll(`.${groupClass}:checked`);
        return Array.from(checkboxes).map(cb => cb.value);
    }

    // Create a filters object from all groups
    function getSelectedFilters() {
        return {
            category: getCheckedValues('category-filter'),
            traffic: getCheckedValues('traffic-filter'),
            location: getCheckedValues('location-filter'),
            da: getCheckedValues('da-filter'),
            dr: getCheckedValues('dr-filter'),
            price: getCheckedValues('price-filter'),
            spam: getCheckedValues('spam-filter'),
            status: getCheckedValues('status-filter'),
            addedby: getCheckedValues('addedby-filter'),
            timeline: getCheckedValues('timeline-filter')
        };
    }

    // Function to Redraw all charts
    function updateAllCharts(data) {
        // 1. Traffic Chart
        if (data.traffic) {
            if (trafficChartInstance) trafficChartInstance.destroy();
            trafficChartInstance = new Chart(document.getElementById('trafficChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.traffic),
                    datasets: [{
                        label: 'Websites by Traffic Range',
                        data: Object.values(data.traffic),
                        backgroundColor: 'rgba(75, 192, 192, 0.7)'
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: 0,
                            max: 35,
                            ticks: {
                                stepSize: 5
                            },
                            title: {
                                display: true,
                                text: 'No of Websites'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Range in Thousands'
                            }
                        }
                    }
                }
            });
        }

        // 2. Category Chart
        if (data.category) {
            if (categoryChartInstance) categoryChartInstance.destroy();
            categoryChartInstance = new Chart(document.getElementById('categoryChart'), {
                type: 'doughnut',
                data: {
                    labels: Object.keys(data.category),
                    datasets: [{
                        label: 'Websites by Category',
                        data: Object.values(data.category),
                        backgroundColor: ['#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0', '#9966FF']
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    layout: {
                        padding: {
                            top: 0,
                            right: 20 // spacing between chart and legend
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'Category Distribution',
                            font: {
                                size: 14,
                                // weight: 'bold'
                            },
                            padding: {
                                top: 10,
                                bottom: 30 // space between title and chart+legend
                            }
                        },
                        legend: {
                            position: 'right',
                            labels: {
                                boxWidth: 20,
                                padding: 10
                            }
                        }
                    }
                }
            });

        }

        // 3. Approval Chart
        if (data.approval) {
            if (approvalChartInstance) approvalChartInstance.destroy();
            approvalChartInstance = new Chart(document.getElementById('approvalChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.approval),
                    datasets: [{
                        label: 'Approved Websites',
                        data: Object.values(data.approval),
                        backgroundColor: 'rgba(153, 102, 255, 0.7)'
                    }]
                },
                options: {
                    maintainAspectRatio: false
                }
            });
        }

        // 4. DA Chart
        if (data.da) {
            if (daChartInstance) daChartInstance.destroy();
            daChartInstance = new Chart(document.getElementById('daChart'), {
                type: 'bar',
                data: {
                    labels: Object.keys(data.da),
                    datasets: [{
                        label: 'Websites by DA Range',
                        data: Object.values(data.da),
                        backgroundColor: 'rgba(255, 159, 64, 0.7)'
                    }]
                },
                options: {
                    maintainAspectRatio: false
                }
            });
        }
    }

    // Function to send filters to server and get chart data
    function applyFilters() {
        const filters = getSelectedFilters();
        console.log(filters);

        fetch('api/chart-data.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(filters)
        })
            .then(res => res.json())
            .then(response => {
                if (response.status !== 'success') {
                    throw new Error(response.message || 'Unknown error from server');
                }
                const data = response.data;
                if (websiteCount) {
                    websiteCount.textContent = data.count;
                }
                updateAllCharts(data);

            })
            .catch(err => {
                console.error('Error fetching chart data:', err);
                alert("Failed to load chart data: " + err.message);
            });
    }

    // Event: Apply button clicked
    applyButton.addEventListener('click', applyFilters);

    // Event: Clear button clicked
    clearButton.addEventListener('click', () => {
        // Clear all checkboxes
        document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
        applyFilters();
    });

    // Optional: Fetch all data initially
    applyFilters();

    // const filters = getSelectedFilters();
    // fetch('api/chart-data.php', {
    //     method: 'POST',
    //     headers: { 'Content-type': 'application/json' },
    //     body: JSON.stringify()
    // })
    // .then(res => res.json())
    // .then(response => {
    //     if (response.status !== 'success') {
    //         throw new Error(response.message || 'Unknown error from server');
    //     }

    //     const data = response.data;

});