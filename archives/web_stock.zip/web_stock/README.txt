
Functionalities Pending:
-Search website
-Search user
-Activate/deactivate user
-edit/delete user
-Pagination
-Forms' Validations- add website, edit website
-import website data in csv
-add name field to users


-Sanitize data in csv
-check for required fields
-columnwise check
-insert into table


confirm for method of file upload/csv->db upload

