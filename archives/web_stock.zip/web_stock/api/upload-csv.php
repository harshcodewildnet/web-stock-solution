<?php
session_start();

if (isset($_POST['submit'])) {
    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error'] = "No file uploaded or upload failed.";
        header("Location: ../uploads.php");
        exit;
    }

    require '../includes/db.php';

    $fileTmpPath = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($fileTmpPath, 'r');

    if ($handle === false) {
        $_SESSION['error'] = "Failed to open uploaded file.";
        header("Location: ../uploads.php");
        exit;
    }

    $expectedHeader = [
        'Category',
        'Url',
        'Currency',
        'Price',
        'Client Name',
        'Blogger Name',
        'Blogger Email',
        'Blogger Mobile',
        'Spam Score',
        'DR',
        'Traffic',
        'DA',
        'Location',
        'Mode',
        'Added By',
        'Status',
        'Approved'
    ];

    $header = fgetcsv($handle);
    if ($header === false || array_map('trim', $header) !== $expectedHeader) {
        $_SESSION['error'] = "Invalid CSV headers. Please download and use the official template.";
        fclose($handle);
        header("Location: ../uploads.php");
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO websites (
        category, url, currency, price, client_name, blogger_name,
        blogger_email, blogger_mobile, spam_score, dr, traffic, da,
        location, mode, added_by, status, approved, date_added
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

    if ($stmt === false) {
        $_SESSION['error'] = "Database error: " . $conn->error;
        fclose($handle);
        header("Location: ../uploads.php");
        exit;
    }

    $rowCount = 0;
    $errorCount = 0;
    $lineNum = 2; // Data starts at line 2
    $invalidRows = [];
    $dataRowExists = false;

    while (($row = fgetcsv($handle)) !== false) {
        if (count(array_filter($row)) === 0) {
            // Empty line
            $lineNum++;
            continue;
        }

        $dataRowExists = true;

        if (count($row) !== count($expectedHeader)) {
            $invalidRows[] = "Line $lineNum: Incorrect number of columns.";
            $errorCount++;
            $lineNum++;
            continue;
        }

        $data = array_map('trim', $row);

        // Field validation
        if (!filter_var($data[1], FILTER_VALIDATE_URL)) {
            $invalidRows[] = "Line $lineNum: Invalid URL.";
            $errorCount++;
            $lineNum++;
            continue;
        }

        if (!filter_var($data[6], FILTER_VALIDATE_EMAIL)) {
            $invalidRows[] = "Line $lineNum: Invalid Email.";
            $errorCount++;
            $lineNum++;
            continue;
        }

        $columnMap = [
            3 => 'Price',
            8 => 'Spam Score',
            9 => 'DR',
            10 => 'Traffic',
            11 => 'DA',
            16 => 'Approved'
        ];

        $fieldErrors = [];

        foreach ($columnMap as $index => $name) {
            if ($index == 16) {
                if (!in_array($data[$index], ['0', '1'])) {
                    $fieldErrors[] = "$name must be 0 or 1";
                }
            } else {
                if (!is_numeric($data[$index])) {
                    $fieldErrors[] = "$name must be a number";
                }
            }
        }

        if (!empty($fieldErrors)) {
            $invalidRows[] = "Line $lineNum: " . implode('; ', $fieldErrors);
            $errorCount++;
            $lineNum++;
            continue;
        }


        // Bind and insert
        $stmt->bind_param(
            "sssdssssdddissssi",
            $data[0],
            $data[1],
            $data[2],
            $data[3],
            $data[4],
            $data[5],
            $data[6],
            $data[7],
            $data[8],
            $data[9],
            $data[10],
            $data[11],
            $data[12],
            $data[13],
            $data[14],
            $data[15],
            $data[16]
        );

        if (!$stmt->execute()) {
            $invalidRows[] = "Line $lineNum: DB insert failed - " . $stmt->error;
            $errorCount++;
        } else {
            $rowCount++;
        }

        $lineNum++;
    }

    fclose($handle);
    $stmt->close();
    $conn->close();

    if (!$dataRowExists) {
        $_SESSION['error'] = "Uploaded file contains No Data";
        header("Location: ../uploads.php");
        exit;
    }

    if ($rowCount > 0) {
        $_SESSION['success'] = "$rowCount row(s) imported successfully.";
    }

    if ($errorCount > 0) {
        $_SESSION['error'] = "$errorCount row(s) skipped due to errors.<br>" . implode("<br>", $invalidRows);
    }

    header("Location: ../uploads.php");
    exit;
}
?>