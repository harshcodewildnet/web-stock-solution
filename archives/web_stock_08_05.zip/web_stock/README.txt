ReadMe for Web_Stock Project

-redirect issues:
    -manage user -> dashboard
    -add-website -> logout




Functionalities Pending:
-Search website
-Search user
-Activate/deactivate user
-edit user 
-Pagination
-Forms' Validations- add website, edit website
-import website data in csv
-edit website
-add name field to users


Graphs to show-
1. Traffic - Bar (Range/Frequency)
2. Category - Donut (Category/Frequency)
3. Approval - Bar(Category/Frequency)
4. DA Range - Bar(Range/Frequency)

-Sanitize data in csv
-check for required fields
-columnwise check
-insert into table
