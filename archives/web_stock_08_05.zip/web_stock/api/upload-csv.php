<?php
if (isset($_POST['submit'])) {
    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        die("Error: No file uploaded or upload failed.");
    }

    require '../includes/db.php'; // Must define $conn = new mysqli(...)

    $fileTmpPath = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($fileTmpPath, 'r');

    if ($handle === false) {
        die("Error: Failed to open uploaded file.");
    }

    // Define expected CSV headers
    $expectedHeader = [
        'category',
        'url',
        'currency',
        'price',
        'client_name',
        'blogger_name',
        'blogger_email',
        'blogger_mobile',
        'spam_score',
        'dr',
        'traffic',
        'da',
        'location',
        'mode',
        'added_by',
        'status',
        'approved'
    ];

    $header = fgetcsv($handle);
    if ($header === false || array_map('trim', $header) !== $expectedHeader) {
        die("Error: Invalid CSV headers. Please use the correct template.");
    }

    // Prepare insert statement
    $stmt = $conn->prepare("INSERT INTO websites (
        category, url, currency, price, client_name, blogger_name,
        blogger_email, blogger_mobile, spam_score, dr, traffic, da,
        location, mode, added_by, status, approved, date_added
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

    if ($stmt === false) {
        die("Database error: " . $conn->error);
    }

    // Counters
    $rowCount = 0;
    $errorCount = 0;

    while (($row = fgetcsv($handle)) !== false) {
        if (count($row) !== count($expectedHeader)) {
            $errorCount++;
            continue;
        }

        $data = array_map('trim', $row);

        // Field validation
        if (!filter_var($data[1], FILTER_VALIDATE_URL) || !filter_var($data[6], FILTER_VALIDATE_EMAIL)) {
            $errorCount++;
            continue;
        }
        if (
            !is_numeric($data[3]) || !is_numeric($data[8]) || !is_numeric($data[9]) ||
            !is_numeric($data[10]) || !is_numeric($data[11]) || !in_array($data[16], ['0', '1'])
        ) {
            $errorCount++;
            continue;
        }

        $stmt->bind_param(
            "sssdssssdddissssi",
            $data[0],
            $data[1],
            $data[2],
            $data[3],
            $data[4],
            $data[5],
            $data[6],
            $data[7],
            $data[8],
            $data[9],
            $data[10],
            $data[11],
            $data[12],
            $data[13],
            $data[14],
            $data[15],
            $data[16]
        );

        if (!$stmt->execute()) {
            $errorCount++;
            continue;
        }

        $rowCount++;
    }

    fclose($handle);
    $stmt->close();
    $conn->close();

    echo "Imported $rowCount rows successfully.<br>";
    if ($errorCount > 0) {
        echo "Skipped $errorCount rows due to validation or database errors.";
    }
}
