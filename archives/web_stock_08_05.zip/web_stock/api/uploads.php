<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if a file was uploaded
if (!isset($_FILES['file-input']) || $_FILES['file-input']['error'] === UPLOAD_ERR_NO_FILE) {
    $_SESSION['error'] = "No file selected.";
    header("Location: ../uploads.php");
    exit;
}

// Store file info
$file = $_FILES['file-input'];
$uploadDir = "../uploads/";
$filename = basename($file['name']);
$targetPath = $uploadDir . $filename;
$fileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

// Set allowed file types
$allowedTypes = ['xls', 'xlsx', 'csv'];

if (!in_array($fileType, $allowedTypes)) {
    $_SESSION['error'] = "Unsupported file type: " . htmlspecialchars($fileType);
    header("Location: ../uploads.php");
    exit;
}

if ($file['size'] > 5 * 1024 * 1024) { // 5 MB limit
    $_SESSION['error'] = "File size exceeds 5MB limit.";
    header("Location: ../uploads.php");
    exit;
}

// Ensure upload directory exists
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Check if file already exists in the uploads directory
if (file_exists($targetPath)) {
    $_SESSION['error'] = "File already exists in uploads : " . htmlspecialchars($filename);
    header("Location: ../uploads.php");
    exit;
}

// Move uploaded file
if (move_uploaded_file($file['tmp_name'], $targetPath)) {

    // Check if filename already exists in db
    $stmt = $conn->prepare("SELECT * FROM uploads WHERE filename = ?");
    $stmt->bind_param("s", $filename);
    $stmt->execute();
    $result = $stmt->get_result();
    // filename already exists
    if ($result->num_rows === 1) {
        $_SESSION['error'] = "File " . $filename . " already exists in database!";
        header("Location: ../uploads.php");
        exit;
    }
    // else insert into table uploads
    $stmt = $conn->prepare("INSERT INTO uploads (filename) VALUES (?)");
    $stmt->bind_param("s", $filename);
    $inserted = $stmt->execute();

    if ($inserted) {
        $_SESSION['success'] = "File uploaded successfully: " . htmlspecialchars($filename);
        header('Location: ../uploads.php');
        exit;
    } else {
        $_SESSION['error'] = "Error Uploading File : " . htmlspecialchars($stmt->error);
        header('Location: ../uploads.php');
        exit;
    }
} else {
    $_SESSION['error'] = "There was a problem uploading the file.";
}

header("Location: ../uploads.php");
exit;
