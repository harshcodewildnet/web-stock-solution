<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- <link rel="stylesheet" href="css/login1.css"> -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        html,
        body {
            height: 100dvh;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            background-color: #0f004a;
        }

        .container {
            width: 100%;
            /* height: 60dvh; */
            /* margin: 4dvh auto 10dvh auto; */
            flex: 1;
            /* background-color: #fff; */
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        .container .logo {
            width: 40%;

            text-align: center;
            padding: 20px 30px;
        }

        .container .logo img {
            max-width: 280px;
            height: auto;
        }

        .container .login-box {
            background-color: #fff;
            width: 40%;
            min-height: 60%;
            padding: 40px 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .login-box h3.head {
            margin-bottom: 20px;
            text-align: start;
            font-weight: 400;
        }

        form {
            /* flex: 1; */
            height: 70%;
            width: 60%;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        form .form-group {
            margin-bottom: 15px;
        }

        form .check-option {
            display: flex;
            align-items: center;
            margin: 15px auto;
            font-size: .9rem;
        }

        form .check-option input {
            scale: 1.2;
            margin-right: 10px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-size: .9rem;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
        }

        form .login-btn {
            display: block;
            margin: 10px auto;
            padding: 10px 10px;
            background-color: #000;
            color: #fff;
            border: none;
            width: 100%;
            cursor: pointer;
        }

        form .create-btn {
            padding: 10px;
            margin: 20px auto;
        }

        form .login-btn:hover {
            background-color: #272727;
        }


        form a.forgot-password {
            text-decoration: underline;
            font-size: .8rem;
            display: block;
            text-align: center;
            cursor: pointer;
            color: #000;

        }

        footer {
            width: 100%;
            height: 10dvh;
            background-color: #fff;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="assets/wnet-image.png" alt="">
        </div>
        <div class="login-box">
            <form id="sendotpform" action="api/login.php" method="POST" novalidate>
                <h3 class="head">Forgot Passord</h3>
                <div class="form-group">
                    <label for="email" class="form-label">Enter Email Address</label>
                    <input type="email" name="email" id="email" placeholder="Enter email to get password OTP" required>
                    <small class="error" style="color:red;display:none;">Please enter a valid email.</small>
                    <!-- <small class="note" style="color:black;">Enter your registered email Id</small> -->
                </div>
                <div class="form-group otp-field"  style="display:none;">
                    <label for="email" class="form-label">Enter OTP</label>
                    <input type="email" name="email" id="email" placeholder="Enter email" required>
                    <small class="error" style="color:red;display:none;">Please enter a valid email.</small>
                </div>

                <button type="submit" class="login-btn">Login</button>
                <!-- <a href="#" class="forgot-password">Forgot Password</a> -->
            </form>
        </div>
    </div>
    <footer></footer>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function (e) {
            let valid = true;

            // Email validation
            const email = document.getElementById('email');
            const emailError = email.nextElementSibling;
            const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            if (!email.value.match(emailPattern)) {
                emailError.style.display = 'block';
                valid = false;
            } else {
                emailError.style.display = 'none';
            }

            // Password validation
            const password = document.getElementById('password');
            const passwordError = password.nextElementSibling;
            if (password.value.length < 6) {
                passwordError.style.display = 'block';
                valid = false;
            } else {
                passwordError.style.display = 'none';
            }

            if (!valid) {
                e.preventDefault(); // Stop form submission if validation fails
            }
        });
    </script>

</body>

</html>