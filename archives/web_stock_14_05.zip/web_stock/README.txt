
Functionalities Pending:
-Search website
-delete website
-Search user
-Activate/deactivate user
-edit/delete user
-Pagination
-Forms' Validations- add website, edit website
-import website data in csv
-add name field to users


-Sanitize data in csv
-check for required fields
-columnwise check
-insert into table


confirm for method of file upload/csv->db upload

master db
qc at admin level and client lvl
live link
calender custom range timeline

users- admin, tl, team member

email to-
    admin
    tl
    for qc->execution->approval

rempve filters:
added by
status

add download data link on dblist
add QC tab and show data 
add approve option on QC tab
