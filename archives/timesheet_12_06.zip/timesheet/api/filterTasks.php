<?php

require_once '../config/config.php';
require_once '../classes/Task.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$employees = $input['employees'] ?? [];
$departments = $input['departments'] ?? [];
$timeline = $input['timeline'] ?? [];

$taskObj = new Task($conn);
$tasks = $taskObj->getFilteredTasks($employees, $departments, $timeline);

echo json_encode($tasks);
