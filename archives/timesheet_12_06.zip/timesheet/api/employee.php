<?php


require_once '../config/config.php';
require_once '../classes/Employee.php';

$empObj = new Employee($conn);

$action = $_POST['action'] ?? '';

$response = ['status' => 'error', 'message' => 'Invalid action'];

switch ($action) {

    // Add a new employee
    case 'add':
        $employeeData = [
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'password' => $_POST['password'],
            'role' => $_POST['password'],
            'dept_id' => $_POST['password'],
            'rm_id' => $_POST['role'],
            'doj' => '2022-01-01'
        ];
        if ($empObj->addEmployee($employeeData))
            $response = ['status' => 'success', 'message' => 'Employee Added Successfully'];
        else
            $response = ['status' => 'error', 'message' => 'Failed to add employee'];
        break;

    // update employee details
    case 'update':
        $id = $_POST['id'];
        $employeeData = [
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'password' => $_POST['password'],
            'role' => $_POST['password'],
            'dept_id' => $_POST['password'],
            'rm_id' => $_POST['role'],
            'doj' => '2022-01-01'
        ];
        if ($empObj->updateEmployee($id, $employeeData))
            $response = ['status' => 'success', 'message' => 'Employee Updated Succeefully'];
        else
            $response = ['status' => 'error', 'message' => 'Failed to update employee'];
        break;

    // Delete an employee
    case 'delete':
        $id = $_POST['id'];
        if ($empObj->deleteEmployee($id))
            $response = ['status' => 'success', 'message' => `Employee with id: $id Deleted`];
        else
            $response = ['status' => 'error', 'message' => `Failed to delete Employee with id : $id`];
        break;

    // Get Employee By Id
    case 'get':
        $id = $_POST['id'];
        $emp = $empObj->getEmployeeById($id);
        if ($emp)
            $response = ['status' => 'success', 'emp' => $emp];
        else
            $response = ['status' => '', 'message' => 'Employee not found'];
        break;

    // List All Employees
    case 'list':
        $employees = $empObj->getAllEmployees();
        $response = ['status' => 'success', 'employees' => $employees];
        break;
}

echo json_encode($response);