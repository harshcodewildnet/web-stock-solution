<?php
// api/login.php
session_start();
require_once '../config/config.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    die('Email and password are required.');
}


// Find employee by email and role
$stmt = $conn->prepare("SELECT * FROM employee WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $emp = $result->fetch_assoc();
    // employee deactived by admin 
    // if (!(int) $emp['status'] == 1) {
    //     // echo 'in if condition';
    //     $_SESSION['error'] = 'emp Deactivated by Admin !';
    //     header("Location: ../index.php");
    //     exit;
    // }
    // Verify password
    if (password_verify($password, $emp['password'])) {
        // Save session data
        $_SESSION['emp_id'] = $emp['emp_id'];
        $_SESSION['name'] = $emp['name'];
        $_SESSION['emp_role'] = $emp['role'];

        // Redirect based on role
        switch ($emp['role']) {
            case 'executive':
                header('Location: ../dashboard-executive.php');
                break;
            case 'rm':
                header('Location: /dashboard-rm.php');
                break;
            case 'admin':
                header('Location: /dashboard-admin.php');
                break;
            default:
                echo "Invalid role.";
        }
        exit;
    } else {
        $_SESSION['error'] = 'Invalid Password';
        header("Location: ../index.php");
    }
}

$_SESSION['error'] = 'Invalid Login credentials';
header("Location: ../index.php");
