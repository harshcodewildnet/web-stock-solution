<?php
session_start();
if (!isset($_SESSION['emp_id']) || empty($_SESSION['emp_id'])) {
    header('Location:index.php');
    exit;
}

$emp_id = $_SESSION['emp_id'];

require_once 'config/config.php';
// require_once 'classes/Department.php';
require_once 'classes/Employee.php';
require_once 'classes/Task.php';
// $result = $conn->query('SELECT e.*, t.* FROM employee e inner join task t on t.emp_id=e.emp_id;');

// $deptObj = new Department($conn);
// $departments = $deptObj->getDepartments();

// $empObj = new Employee($conn);
// $employees = $empObj->getAllEmployees();

$taskObj = new Task($conn);
$empTasks = $taskObj->getEmployeeTasks($emp_id);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="assets/css/index2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="assets/js/add.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        canvas {
            max-width: 100%;
            margin: 10px auto;
            display: block;
        }

        .top-row .left .filter-multiselect {
            width: 150px;
            position: relative;
            /* margin-right: 20px; */
            /* border: 1px solid red; */
        }

        .filter-multiselect .select-box {
            background-color: #ffffff;
            /* border: 1px solid red; */
            /* padding: 10px 10px; */
            padding: 8px 10px;
            text-align: center;
            font-size: .7rem;
            font-weight: 600;
            cursor: pointer;
        }

        .filter-multiselect .select-box:hover {
            background-color: #d9d9d9;
        }

        .filter-multiselect .select-box i {
            margin-left: 10px;
        }

        .filter-multiselect .options {
            position: absolute;
            top: 110%;
            left: 0;
            width: 180px;
            background-color: #f1f1f1;
            padding: 10px;
            display: none;
            flex-direction: column;
            gap: 5px;
            z-index: 10;
        }

        .filter-multiselect.active .options {
            display: flex;
            max-height: 50dvh;
            overflow: auto;
        }

        .options label {
            display: flex;
            align-items: baseline;
            gap: 8px;
            cursor: pointer;
            font-size: .8rem;
            /* background-color: #fff; */
        }

        .options label input[type=checkbox] {
            transform: scale(1.1);
        }

        .options label input[type=checkbox].custom-range-checkbox {
            margin-right: 4px;
        }

        .options label#custom-range-label {
            display: block;
        }

        .options label .custom-date-range {
            font-size: .8rem;
            padding: 0 10px;
        }

        .options label .custom-date-range input[type="date"] {
            margin: 0px 5px;
            padding: 0px 5px;
            font-size: .7rem;
        }
    </style>
</head>

<body>
    <!-- Header Dblist-->
    <header>
        <a href="dashboard.php">
            <div class="logo">
                <img src="assets/images/wnet-image.png" alt="WildNet logo">
            </div>
        </a>
        <div class="search-area">
            <h3 class="head">Welcome Amit</h3>
        </div>
    </header>
    <aside>
        <nav class="sidenav">
            <div class="nav-tabs">
                <div class="profile-img">
                    <img src="assets/images/profile-img.jpg" alt="profile-img">
                    <i class="fa-solid fa-pencil"></i>
                </div>
                <div class="profile-head">
                    <h4>Amit Kumar</h4>
                    <h5>Emp Id: 1912</h5>
                </div>
                <a href="#" class="tab">
                    <i class="fa-solid fa-house"></i> Home
                </a>
                <!-- <a href="manage-user.php" class="tab">
                    <i class="fa-solid fa-user"></i> Manage User
                </a> -->
                <a href="profile.php" class="tab">
                    <i class="fa-solid fa-user"></i> My Account
                </a>
                <a href="report.php" class="tab">
                    <i class="fa-solid fa-clipboard-list"></i> Report
                </a>
            </div>
        </nav>
    </aside>
    <main>
        <div class="top-row">
            <div class="left">
                <div class="filter-multiselect">
                    <div class="select-box">Timeline<i class="fa-solid fa-caret-down"></i></div>
                    <div class="options">
                        <label><input type="checkbox" class="select-all timeline-filter" value="">Select All</label>
                        <label><input type="checkbox" class="filter-option timeline-filter" value="today"> Today</label>
                        <label><input type="checkbox" class="filter-option timeline-filter" value="last7"> Last 7
                            Days</label>
                        <label><input type="checkbox" class="filter-option timeline-filter" value="last30"> Last 30
                            Days</label>
                        <label id="custom-range-label">
                            <input type="checkbox" class="timeline-filter custom-range-checkbox" value="custom"> Custom
                            <div class="custom-date-range" style="display: none;">
                                From -
                                <input type="date" class="custom-from-date" placeholder="From">
                                To -
                                <input type="date" class="custom-to-date" placeholder="To">
                            </div>
                        </label>
                    </div>
                </div>
                <!-- </div> -->
            </div>
            <div class="right">
                <button class="add-btn" id="open-modal-btn"><i class="fa-solid fa-plus-circle"></i>Add New</button>
            </div>
        </div>
        <div class="content-area">
            <div class="tasklist grid-item">
                <table id="tasktable">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Working/Leave</th>
                            <th>Nature of Task</th>
                            <th>Task Brief</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Comments</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>20-04-2025</td>
                            <td>Working</td>
                            <td>Scrum Call</td>
                            <td>Meeting with dev team</td>
                            <td>02:00</td>
                            <td>Approved</td>
                            <td>-</td>
                        </tr>
                    </tbody>
                </table>


            </div>
            <div class="graph graph1 grid-item">
                <h5>Weekly Work Hours</h5>
                <!-- Area Chart -->
                <canvas id="hoursChart"></canvas>
            </div>
            <div class="graph graph2 grid-item">
                <h5>Leaves</h5>
                <!-- Line Chart -->
                <canvas id="leavesChart"></canvas>
            </div>
            <div class="graph graph3 grid-item">
                <h5>Working Days</h5>
                <!-- Pie Chart -->
                <canvas id="workdaysChart"></canvas>
            </div>
        </div>



    </main>
    <!-- <footer></footer> -->
    <?php
    include_once 'modal.php';
    ?>






    <script src="assets/js/filters.js"></script>
    <!-- Graphs Script -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // Gross Hours Chart
        const areaCtx = document.getElementById('hoursChart').getContext('2d');
        const areaChart = new Chart(areaCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
                datasets: [{
                    label: 'Hours Worked',
                    data: [8, 7.5, 9, 8.5, 7],
                    backgroundColor: 'rgba(75, 192, 192, 0.4)', // Area fill
                    borderColor: 'rgba(75, 192, 192, 1)', // Line
                    borderWidth: 2,
                    fill: true, // This makes it an area chart
                    tension: 0.4
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // 
        const donutCtxLeaves = document.getElementById('leavesChart').getContext('2d');

        // Example: Leaves Score out of ?
        const leavesScore = 4; // You can dynamically pass this value
        const totalAllottedLeaves = 12; // Total working days
        const remainingLeaves = totalAllottedLeaves - leavesScore;

        const donutChartLeaves = new Chart(donutCtxLeaves, {
            type: 'doughnut',
            data: {
                labels: [`Leaves Taken (${leavesScore} / ${totalAllottedLeaves})`, `Available (${remainingLeaves})`],
                datasets: [{
                    data: [leavesScore, 12 - leavesScore],
                    backgroundColor: [
                        'rgba(200, 200, 200, 0.5)',  // Remaining
                        'rgba(54, 162, 235, 0.8)' // Productive
                    ],
                    borderColor: [
                        'rgba(200, 200, 200, 1)',
                        'rgba(54, 162, 235, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                cutout: '70%', // Creates the donut effect
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return context.label + ': ' + context.parsed + '';
                            }
                        }
                    }
                }
            }
        });

        const donutCtxWorkdays = document.getElementById('workdaysChart').getContext('2d');

        // Example: Days Worked out of Total Working Days
        const workingdaysScore = 18; // Days worked
        const totalWorkingDays = 22; // Total working days
        const remainingDays = totalWorkingDays - workingdaysScore;

        const donutChartDays = new Chart(donutCtxWorkdays, {
            type: 'doughnut',
            data: {
                labels: [`Days Worked (${workingdaysScore} / ${totalWorkingDays})`, `Remaining Days (${remainingDays})`],
                datasets: [{
                    data: [workingdaysScore, remainingDays],
                    backgroundColor: [
                        'rgba(243, 135, 255, 0.8)', // Days Worked
                        'rgba(200, 200, 200, 0.5)'   // Remaining Days
                    ],
                    borderColor: [
                        'rgba(243, 135, 255, 1)',
                        'rgba(200, 200, 200, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                cutout: '70%',
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return `${context.label}: ${context.parsed} days`;
                            }
                        }
                    }
                }
            }
        });



    </script>


</body>

</html>