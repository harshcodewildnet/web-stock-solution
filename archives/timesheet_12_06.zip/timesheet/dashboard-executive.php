<?php
require_once 'config/config.php';
$result = $conn->query('SELECT e.*, t.* FROM employee e inner join task t on t.emp_id=e.emp_id;');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <script src="assets/js/add.js"></script>
</head>

<body>
    <!-- Header Dblist-->
    <header>
        <a href="dashboard.php">
            <div class="logo">
                <img src="assets/images/wnet-image.png" alt="WildNet logo">
            </div>
        </a>
        <div class="search-area">
            <h3 class="head">Welcome User</h3>
            <div class="actions">
                <label id="profile-label">
                    <i class="fa-solid fa-user"></i>
                    <button id="profile-toggle">
                        <i class="fa-solid fa-caret-down"></i>
                    </button>
                    <div id="profile-dropdown" class="profile-dropdown">
                        <a href="manage-profile.php" class="dropdown-item">My Profile</a>
                        <hr>
                        <a href="manage-profile.php" class="dropdown-item">Reset Password</a>
                    </div>
                </label>
                <a href="#" id="logout-link">
                    <i class="fa-solid fa-power-off"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </header>
    <aside>
        <nav class="sidenav">
            <div class="nav-tabs">
                <div class="profile-img">
                    <img src="assets/images/profile-img.jpg" alt="profile-img">
                </div>
                <a href="index.php" class="tab">
                    <i class="fa-solid fa-house"></i> Home
                </a>
                <!-- <a href="manage-user.php" class="tab">
                    <i class="fa-solid fa-user"></i> Manage User
                </a> -->
                <a href="profile.php" class="tab">
                    <i class="fa-solid fa-user"></i> My Account
                </a>
                <a href="report.php" class="tab">
                    <i class="fa-solid fa-clipboard-list"></i> Report
                </a>
            </div>
        </nav>
    </aside>
    <main>
        <!-- top panel -->
        <!-- <div class="top-panel">
            Filter Boxes
            <div class="filler"></div>
            <div class="details-card">
                <h4 class="card-title">Quick Analysis</h4>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-leaf"></i></span>
                    <span class="label">Total leaves -</span>
                    <span class="value">0</span>
                </div>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-calendar-days"></i></span>
                    <span class="label green">Total days -</span>
                    <span class="value">22</span>
                </div>
                <div class="detail-item">
                    <span class="icon"><i class="fa-solid fa-square-plus"></i></span>
                    <span class="label blue">Gross Hours -</span>
                    <span class="value">176h22m</span>
                </div>
            </div>
        </div> -->
        <!-- content -->
        <div class="content-area">
            <div class="table-wrapper">
                <table class="sitelist">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Working/Leave</th>
                            <th>Nature of Task</th>
                            <th>Task Brief</th>
                            <th>Time Taken</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="siteTableBody">

                        <?php
                        if ($result->num_rows > 0) {
                            while ($task = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?= $task['date'] ?></td>
                                    <!-- <td><?= $task['name'] ?></td> -->
                                    <td>
                                        <!-- <select name="">
                                            <option value="">Working</option>
                                            <option value="">Leave</option>
                                        </select> -->
                                        Working
                                    </td>
                                    <td><?= $task['category'] ?></td>
                                    <td><?= $task['description'] ?></td>
                                    <td>
                                        <!-- <select name="time" id="time">
                                            <option value="">0:30</option>
                                            <option value="">1:00</option>
                                            <option value="">1:30</option>
                                            <option value="">2:00</option>
                                            <option value="">2:30</option>
                                        </select> -->
                                        <?= $task['duration'] ?>
                                    </td>
                                    <td>
                                        <select name="status" id="status">
                                            <option value="" selected>Approved</option>
                                            <option value="" <?= ($task['status'] == '1') ? '' : 'selected' ?>>Not Approved
                                            </option>
                                        </select>
                                        <?= ($task['status'] == '1') ? 'Approved' : 'Not Approved' ?>
                                    </td>
                                    <td>-</td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                        <tr class="entry-row">
                            <td><input type="date"></td>
                            <td>
                                <select name="">
                                    <option value="">Working</option>
                                    <option value="">Leave</option>
                                </select>
                            </td>
                            <td><input type="text" placeholder="Enter Task Category"></td>
                            <td><input type="text" placeholder="Enter Task Description"></td>
                            <td>
                                <select name="time" id="time">
                                    <option value="">0:30</option>
                                    <option value="">1:00</option>
                                    <option value="">1:30</option>
                                    <option value="">2:00</option>
                                    <option value="">2:30</option>
                                </select>
                            </td>
                            <td>
                                <select name="status" id="status" disabled>
                                    <option value="0" selected>Not Approved</option>
                                    <option value="1">Approved</option>
                                </select>
                            </td>
                            <td><i class="fa-regular fa-trash-can"></i></td>
                        </tr>
                        <!-- <tr class="add-btn-row">
                            <td colspan="7">
                                <button class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
                            </td>
                        </tr> -->
                    </tbody>
                </table>
                <div class="actions">
                    <button id="submit-btn" class="add-btn">Submit</button>
                    <button id="add-btn" class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
                </div>
            </div>
            <div class="bottom-panel">
                <div class="left">
                    <canvas id="trafficChart"></canvas>
                </div>
                <div class="right"></div>
            </div>
        </div>
    </main>
    <!-- <footer></footer> -->
    <script src="assets/js/filters.js"></script>
    <!-- Graphs Script -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>

        trafficChartInstance = new Chart(document.getElementById('trafficChart'), {
            type: 'bar',
            data: {
                labels: Object.keys(data.traffic),
                datasets: [{
                    label: 'Websites by Traffic Range',
                    data: trafficValues,
                    backgroundColor: 'rgba(72, 231, 231, 0.7)'
                }]
            },
            options: {
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: bufferedMax,
                        grid: {
                            display: false
                        },
                        ticks: {
                            precision: 0,
                            stepSize: 5
                        },
                        title: {
                            display: true,
                            text: 'No of Websites'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Range in Thousands'
                        },
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    datalabels: {
                        // color: function (context) {
                        //     const value = context.dataset.data[context.dataIndex];
                        //     If value is less than 25% of max, use black label on top
                        //     return value < (bufferedMax * 0.25) ? '#008383' : '#008383';
                        // },
                        color: 'rgb(0, 131, 131)',
                        anchor: function (context) {
                            const value = context.dataset.data[context.dataIndex];
                            return value < (bufferedMax * 0.25) ? 'end' : 'center';
                        },
                        align: function (context) {
                            const value = context.dataset.data[context.dataIndex];
                            return value < (bufferedMax * 0.25) ? 'top' : 'center';
                        },
                        font: {
                            weight: 'bold',
                            size: 14,
                        },
                        formatter: Math.round
                    }
                }
            },
            plugins: [ChartDataLabels]
        });

    </script>
</body>

</html>