<?php

class Task
{
    private $conn;

    public function __construct($conn)
    {
        $this->con = $conn;
    }

    public function getEmployeeTasks($id)
    {
        $stmt = $this->conn->prepare('SELECT * FROM task WHERE emp_id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();

    }

    public function getFilteredTasks($employees, $departments, $timeline)
    {
        $query = 'SELECT t.*, e.name as emp_name, d.dept_name from task t join employee e on ';
    }

}