<?php

class Department
{
    private $conn;
    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function getDepartments()
    {
        $departments = [];
        $result = $this->conn->query('SELECT * FROM department');
        while ($row = $result->fetch_assoc()) {
            $departments[] = $row;
        }

        return $departments;
    }

    public function getDepartmentById($id)
    {
        $result = $this->conn->query("SELECT * FROM department WHERE dept_id = $id");
        return $result->fetch_assoc();
    }

    public function addDepartment($department)
    {
        $stmt = $this->conn->prepare('INSERT INTO department(dept_name, dept_head, emp_count, dept_email) VALUES(?, ?, ?, ?)');
        $stmt->bind_param('siis', $department['dept_name'], $department['dept_head'], $department['emp_count'], $department['dept_email']);
        return $stmt->execute();
    }
}