<?php

class Employee
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function getAllEmployees()
    {
        $employees = [];
        $result = $this->conn->query('SELECT * FROM employee');
        while ($row = $result->fetch_assoc()) {
            $employees[] = $row;
        }

        return $employees;
    }

    public function getEmployeeById($id)
    {
        $stmt = $this->conn->prepare('SELECT * FROM employee WHERE emp_id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function addEmployee($employee)
    {
        $stmt = $this->conn->prepare('INSERT INTO employee(name, email, password, role, dept_id, rm_id, doj) VALUES(?,?,?,?,?,?,?)');
        $stmt->bind_param('ssssiis', $employee['name'], $employee['email'], $employee['password'], $employee['role'], $employee['dept_id'], $employee['rm_id'], $employee['doj']);
        return $stmt->execute();
    }

    public function updateEmployee($id, $employee)
    {
        $stmt = $this->conn->prepare('UPDATE employee SET name=?, email=?, password=?, role=?, dept_id=?, rm_id=?, doj=? WHERE emp_id=?');
        $stmt->bind_param('ssssiisi', $employee['name'], $employee['email'], $employee['password'], $employee['role'], $employee['dept_id'], $employee['rm_id'], $employee['doj'], $id);
        return $stmt->execute();
    }

    public function deleteEmployee($id)
    {
        $stmt = $this->conn->prepare('DELETE FROM employee WHERE emp_id = ?');
        $stmt->bind_param('i', $id);
        return $stmt->execute();
    }


}