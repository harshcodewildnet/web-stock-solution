
// Filter Script

const filters = document.querySelectorAll('.filter-multiselect');

filters.forEach(filter => {
    const selectBox = filter.querySelector('.select-box');
    const options = filter.querySelector('.options');

    // Toggle dropdown
    selectBox.addEventListener('click', (e) => {
        e.stopPropagation();

        if (filter.classList.contains('active')) {
            filter.classList.remove('active');
            return;
        }

        filters.forEach(f => {
            if (f !== filter) f.classList.remove('active');
        });

        filter.classList.add('active');
    });

    if (options) {
        options.addEventListener('click', e => e.stopPropagation());
    }
});

// Close all on outside click
window.addEventListener('click', () => {
    filters.forEach(filter => {
        filter.classList.remove('active');
    });
});


// Select All Checkbox Script
document.querySelectorAll('.select-all').forEach(selectAllCheckbox => {
    selectAllCheckbox.addEventListener('change', function () {
        const container = this.closest('.filter-multiselect');
        const checkboxes = container.querySelectorAll('input[type="checkbox"]:not(.select-all)');
        checkboxes.forEach(cb => cb.checked = this.checked);
    });
});

// Sync "Select All" when individual checkboxes are changed
document.querySelectorAll('.filter-option').forEach(option => {
    option.addEventListener('change', function () {
        const container = this.closest('.filter-multiselect');
        const allCheckboxes = container.querySelectorAll('.filter-option');
        const allChecked = Array.from(allCheckboxes).every(cb => cb.checked);
        container.querySelector('.select-all').checked = allChecked;
    });
});


// Timeline Calender
document.addEventListener("DOMContentLoaded", function () {
    const customCheckbox = document.querySelector('.custom-range-checkbox');
    const dateRange = document.querySelector('.custom-date-range');
    const allCheckboxes = document.querySelectorAll('.timeline-filter:not(.custom-range-checkbox)');
    const fromDate = document.querySelector('.custom-from-date');
    const toDate = document.querySelector('.custom-to-date');

    // Handle custom checkbox toggle
    customCheckbox.addEventListener('change', function () {
        if (this.checked) {
            dateRange.style.display = 'block';

            // Disable other checkboxes
            allCheckboxes.forEach(cb => {
                cb.checked = false;
            });
        } else {
            dateRange.style.display = 'none';
        }
    });

    // Handle other checkboxes
    allCheckboxes.forEach(cb => {
        cb.addEventListener('change', function () {
            if (this.checked) {
                customCheckbox.checked = false;
                dateRange.style.display = 'none';
            }
        });
    });

    dateRange.style.display = customCheckbox.checked ? 'block' : 'none';
});


document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.querySelector('.employee-filter-input');
    const employeeOptions = document.querySelectorAll('.employee-option');

    searchInput.addEventListener('keyup', function () {
        const filterValue = searchInput.value.toLowerCase();

        employeeOptions.forEach(option => {
            const labelText = option.textContent.toLowerCase();
            if (labelText.includes(filterValue)) {
                option.style.display = 'block';
            } else {
                option.style.display = 'none';
            }
        });
    });
});
