document.addEventListener('DOMContentLoaded', function () {
    const addButton = document.querySelector('#add-btn');
    const tableBody = document.querySelector('#tasktablebody');
    addButton.addEventListener('click', () => {
        let rowEl = document.createElement('tr');
        rowEl.classList.add('entry-row');
        rowEl.innerHTML = `
                    <td><input type="date"></td>
                    <td>
                        <select name="">
                            <option value="Working">Working</option>
                            <option value="Leave">Leave</option>
                            <option value="Week Off">Week Off</option>
                            <option value="Half Day Leave">Half Day Leave</option>
                            <option value="Public Holiday">Public Holiday</option>
                        </select>
                    </td>
                    <td><input type="text" placeholder="Enter Task Category"></td>
                    <td><input type="text" placeholder="Enter Task Description"></td>
                    <td>
                        <select name="time" id="time">
                            <option value="">0:30</option>
                            <option value="">1:00</option>
                            <option value="">1:30</option>
                            <option value="">2:00</option>
                            <option value="">2:30</option>
                        </select>
                    </td>
                    <td>
                        <select name="status" id="status" disabled>
                            <option value="0" selected>Not Approved</option>
                            <option value="1">Approved</option>
                        </select>
                    </td>
                    <td><i class="fa-regular fa-trash-can"></i></td>
        `;

        tableBody.appendChild(rowEl);
    });

    // document.querySelectorAll('.fa-trash-can').forEach(delBtn => {
    //     delBtn.addEventListener('click', function () {
    //         this.closest('tr').remove();
    //     });
    // });

    tableBody.addEventListener('click', function (e) {
        if (e.target.classList.contains('fa-trash-can')) {
            e.target.closest('tr').remove();
        }
    });


});