<!-- Common Modal for View/Edit -->
<div class="modal-dialog" id="modal-dialog-common">
    <div class="modal">
        <div class="modal-header">
            <h4 id="modal-title">AddEntry</h4>
            <button class="close-btn" id="close-btn"><i class="fa-solid fa-circle-xmark"></i></button>
        </div>
        <hr>
        <div class="modal-body">
            <!-- <div class="table-wrapper"> -->
            <table class="entry-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Working/Leave</th>
                        <th>Nature of Task</th>
                        <th>Task Brief</th>
                        <th>Time Taken</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="tasktablebody">
                    <tr class="entry-row">
                        <td><input type="date"></td>
                        <td>
                            <select name="">
                                <option value="">Working</option>
                                <option value="">Leave</option>
                            </select>
                        </td>
                        <td><input type="text" placeholder="Enter Task Category"></td>
                        <td><input type="text" placeholder="Enter Task Description"></td>
                        <td>
                            <select name="time" id="time">
                                <option value="">0:30</option>
                                <option value="">1:00</option>
                                <option value="">1:30</option>
                                <option value="">2:00</option>
                                <option value="">2:30</option>
                            </select>
                        </td>
                        <td>
                            <select name="status" id="status" disabled>
                                <option value="0" selected>Not Approved</option>
                                <option value="1">Approved</option>
                            </select>
                        </td>
                        <td><i class="fa-regular fa-trash-can"></i></td>
                    </tr>
                    <!-- <tr class="add-btn-row">
                            <td colspan="7">
                                <button class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
                            </td>
                        </tr> -->
                </tbody>
            </table>
            <div class="actions">
                <button id="submit-btn" class="add-btn">Submit</button>
                <button id="add-btn" class="add-btn"><i class="fa-solid fa-circle-plus"></i>Add New</button>
            </div>
            <!-- </div> -->
        </div>
    </div>
</div>

<script>
    const addModal = document.getElementById('modal-dialog-common');
    // const addButton = document.getElementById('add-btn');
    const openButton = document.getElementById('open-modal-btn');
    const closeButton = document.getElementById('close-btn');

    openButton.addEventListener('click', function (e) {
        addModal.classList.add('show');
    });

    // Close modal
    closeButton.addEventListener('click', () => {
        addModal.classList.remove('show');
    });

    window.addEventListener('click', (e) => {
        if (addModal === e.target) addModal.classList.remove('show');
    })

</script>